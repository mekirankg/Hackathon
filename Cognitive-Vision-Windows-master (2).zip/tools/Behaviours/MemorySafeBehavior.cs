﻿using System.Windows;
using System.Windows.Interactivity;

namespace Pelco.Phoenix.OverlayAPITester.Behaviours
{
    /// <summary>
    /// A behavior that minimizes memory leaks.
    /// Code found here: http://wp7nl.codeplex.com/SourceControl/changeset/view/20956#214132
    /// </summary>
    /// <typeparam name="T">The class type of AssociatedObject.</typeparam>
    public abstract class MemorySafeBehavior<T> : Behavior<T> where T : FrameworkElement
    {
        private bool _initialized = false;

        /// <summary>
        /// Whether the behavior is in the cleaned up state.
        /// </summary>
        protected bool IsCleanedUp { get; private set; }

        /// <summary>
        /// Constructor.
        /// </summary>
        protected MemorySafeBehavior()
        {
            IsCleanedUp = true;
        }

        /// <summary>
        /// Called when the behavior is attached.
        /// </summary>
        protected override void OnAttached()
        {
            base.OnAttached();
            if (!_initialized)
            {
                // WeakEventManager is being used so we don't need to unsubscribe from Loaded and Unloaded later to prevent memory leaks.
                // We need to do this because if we unsubscribe from Loaded and the control gets unloaded and then re-loaded, the behavior
                // will stop working.
                WeakEventManager<T, RoutedEventArgs>.AddHandler(AssociatedObject, "Loaded", AssociatedObjectLoaded);
                WeakEventManager<T, RoutedEventArgs>.AddHandler(AssociatedObject, "Unloaded", AssociatedObjectUnloaded);
                _initialized = true;
            }
        }

        /// <summary>
        /// Called when the behavior is detaching.
        /// </summary>
        protected override void OnDetaching()
        {
            if (_initialized)
            {
                WeakEventManager<T, RoutedEventArgs>.RemoveHandler(AssociatedObject, "Loaded", AssociatedObjectLoaded);
                WeakEventManager<T, RoutedEventArgs>.RemoveHandler(AssociatedObject, "Unloaded", AssociatedObjectUnloaded);
                _initialized = false;
            }
            // Behavior detached so cleanup the behavior.
            Cleanup();
            base.OnDetaching();
        }

        /// <summary>
        /// Called when the associated object is loaded.
        /// </summary>
        private void AssociatedObjectLoaded(object sender, RoutedEventArgs e)
        {
            // Control is loaded so setup the behavior.
            Setup();
        }

        /// <summary>
        /// Called when the associated object is unloaded.
        /// </summary>
        private void AssociatedObjectUnloaded(object sender, RoutedEventArgs e)
        {
            // Control is unloaded so cleanup the behavior.
            Cleanup();
        }

        /// <summary>
        /// Sets up the behavior after the control is loaded.
        /// </summary>
        private void Setup()
        {
            if (IsCleanedUp)
            {
                try
                {
                    // Setup the behavior (e.g. attach events)
                    OnSetup();
                    // Puts the behavior in the correct state upon startup (e.g. Set the AssociatedObject's width or text)
                    Initialize();
                }
                finally
                {
                    // Make the behavior as setup.
                    IsCleanedUp = false;
                }
            }
        }

        /// <summary>
        /// Executes at OnDetaching or OnUnloaded (usually the latter).
        /// </summary>
        private void Cleanup()
        {
            if (!IsCleanedUp)
            {
                try
                {
                    // Cleanup the behavior (e.g. remove events)
                    OnCleanup();
                }
                finally
                {
                    IsCleanedUp = true;
                }
            }
        }

        /// <summary>
        /// Override this to add your own setup (e.g. add events).
        /// </summary>
        protected abstract void OnSetup();

        /// <summary>
        /// Called in the AssociatedObject Loaded event right after OnSetup. Use to run initialization logic for the behavior. 
        /// This is important to get the behavior in the correct state because events hooked up in OnSetup() may not fire right 
        /// away. ScrollViewerChangedBehavior.cs is an example of a behavior that uses this function.
        /// </summary>
        protected abstract void Initialize();

        /// <summary>
        /// Override this to add your own cleanup (e.g. remove events).
        /// </summary>
        protected abstract void OnCleanup();
    }
}