﻿using System;

namespace Pelco.Phoenix.UI.Core.Converters
{

    /// <summary>
    /// Converts boolean value to boolean opposite
    /// </summary>
    public sealed class ReverseBooleanConverter : BooleanConverter<Boolean>
    {
        public ReverseBooleanConverter() :
            base(false, true) { }
    }

}
