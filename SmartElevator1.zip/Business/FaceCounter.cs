﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Emgu.CV;
using Emgu.CV.Structure;
using System.Drawing;
using System.IO;
using SmartElevators.ViewModel;
using SmartElevators.Utils;
using System.Reflection;
using System.Windows.Media.Imaging;
using GalaSoft.MvvmLight.Messaging;
using SmartElevators.Messaging;

namespace SmartElevators.Business
{
    public class FaceCounter
    {
        public int FaceCount { get; set; }
        public List<int> FaceCounts { get; set; }
        private VideoCapture _capture = null;
        private Mat _frame;
        private int peopleCount { get; set; }

        private string CapturedImage { get; set; }
        string currentPath = string.Empty;
        public bool StartDetection(string rtspURL = "rtsp://10.1.26.117/stream1")
        {
            ViewModelLocator.MainVM.CamIP = rtspURL;
            FaceCounts = new List<int>();
            AppLogger.Info("StartDetection start");
            try
            {
                peopleCount = 0;
                _capture = new VideoCapture(rtspURL);
                _capture.ImageGrabbed += ProcessFrame;
                _capture.Start();
            }
            catch (NullReferenceException excpt)
            {
                AppLogger.Error("StartDetection End", excpt);
                //MessageBox.Show(excpt.Message); TODO Log
                return false;
            }
            catch (Exception excpt)
            {
                AppLogger.Error("StartDetection End", excpt);
                //MessageBox.Show(excpt.Message); TODO Log
                return false;
            }
            _frame = new Mat();
            AppLogger.Info("StartDetection End");
            return true;
        }

        private async void ProcessFrame(object sender, EventArgs arg)
        {
            AppLogger.Info("ProcessFrame start");
            try
            {

                if (_capture != null && _capture.Ptr != IntPtr.Zero)
                {
                    _capture.Retrieve(_frame, 0);

                    #region detection logic

                    currentPath = Path.GetDirectoryName(new Uri(Assembly.GetExecutingAssembly().CodeBase).LocalPath);
                    //   string fileName1 = currentPath + "\\Resources\\haarcascade_frontalface_alt_tree.xml";
                    string fileName2 = currentPath + "\\Resources\\haarcascade_frontalface_default.xml";
                    //  string fileName3 = currentPath + "\\Resources\\haarcascade_frontalface_alt_tree.xml";
                    // var _cascadeClassifier = new CascadeClassifier(@"Resources\haarcascade_frontalface_alt_tree.xml");
                    // var _cascadeClassifier1 = new CascadeClassifier(@"Resources\haarcascade_frontalface_default.xml");
                    // var _cascadeClassifier2 = new CascadeClassifier(@"Resources\HS.xml");

                    //    var _cascadeClassifier = new CascadeClassifier(fileName1);
                    var _cascadeClassifier1 = new CascadeClassifier(fileName2);
                    //  var _cascadeClassifier2 = new CascadeClassifier(fileName3);


                    using (var imageFrame = _frame.ToImage<Bgr, Byte>())//_capture.QueryFrame().ToImage<Bgr, Byte>())
                    {
                        if (imageFrame != null)
                        {
                            var grayframe = imageFrame.Convert<Gray, byte>();
                            //   var altTreeFace = _cascadeClassifier.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                            var defaultFace = _cascadeClassifier1.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                                                                                                                    // var faces2 = _cascadeClassifier1.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                                                                                                                    //var actualFace = GetValidFace(altTreeFace, defaultFace, faces2);
                            FaceCount = defaultFace.Length;
                            FaceCounts.Add(FaceCount);
                            if (peopleCount < FaceCount)
                            {
                                peopleCount = FaceCount;

                                // if()
                                //  FaceCounts.Add(altTreeFace.Length);
                                //  ViewModelLocator.MainVM.FaceCount = FaceCount;
                                // Console.WriteLine(DateTime.Now + "-" + FaceCount);
                                foreach (var face in defaultFace)
                                {
                                    imageFrame.Draw(face, new Bgr(Color.BurlyWood), 3); //the detected face(s) is highlighted here using a box that is drawn around it/them   
                                    var fileName = currentPath + "\\CapturedImages\\" + DateTime.Now.ToString("MM-dd-yyyy") + Guid.NewGuid().ToString("D") + ".bmp";
                                    imageFrame.Bitmap.Save(fileName);
                                    await Task.Delay(200);
                                    //  Messenger.Default.Send<CapturedImageMessage>(new CapturedImageMessage()
                                    // {
                                    //      ImagePath = fileName
                                    //  });
                                    CapturedImage = fileName;
                                    //  string selectedFileName = fileName;
                                    //  AppLogger.Info("Image saved- " + fileName);

                                    #region Mask
                                    //Mask detection
                                    /*
                                                                    using (var cascadeMouth = new CascadeClassifier(@"Resources\haarcascade_mcs_mouth.xml"))
                                                                    using (var cacsadeNose = new CascadeClassifier(@"Resources\haarcascade_mcs_nose.xml"))
                                                                    {
                                                                        var Mouths = cascadeMouth.DetectMultiScale(grayframe, 1.1, 10, Size.Empty);
                                                                        var noses = cacsadeNose.DetectMultiScale(grayframe, 1.1, 10, Size.Empty);
                                                                        Console.WriteLine("Mouths : " + Mouths.Length);
                                                                        Console.WriteLine("Noses : " + noses.Length);

                                                                        if(Mouths.Length< defaultFace.Length||noses.Length< defaultFace.Length)
                                                                        {
                                                                            Console.WriteLine("Mask detected");
                                                                            ViewModelLocator.MainVM.ErrorMsg = "Mask detected";
                                                                        }
                                                                    }*/
                                    #endregion

                                }
                            }
                            // if (FaceCount > 0)
                            //  {
                            //Scope of timer.
                            //  _capture.Stop();

                            // }
                        }

                    }

                    #region Mask
                    /* 
                        using (var _cascadeClassifierDefault = new CascadeClassifier(@"Resources\haarcascade_frontalface_default.xml"))
                        {
                            using (var imageFrame = _frame.ToImage<Bgr, Byte>())//_capture.QueryFrame().ToImage<Bgr, Byte>())
                            {
                                if (imageFrame != null)
                                {
                                    var grayframe = imageFrame.Convert<Gray, byte>();
                                    var altTreeFace = _cascadeClassifier_alt.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                                    var defaultFace = _cascadeClassifierDefault.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                                    foreach (var face in defaultFace)
                                    {
                                        using (var cascadeMouth = new CascadeClassifier(@"Resources\haarcascade_mcs_mouth.xml"))
                                        using (var cacsadeNose = new CascadeClassifier(@"Resources\haarcascade_mcs_nose.xml"))
                                        {
                                            var Mouths = cascadeMouth.DetectMultiScale(grayframe, 1.1, 10, Size.Empty);
                                            var noses = cacsadeNose.DetectMultiScale(grayframe, 1.1, 10, Size.Empty);
                                            Console.WriteLine("Mouths : " + Mouths.Length);
                                            Console.WriteLine("Noses : " + noses.Length);
                                        }

                                    }
                                    var faces2 = _cascadeClassifierDefault.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                                    var actualFace = GetValidFace(altTreeFace, defaultFace, faces2);
                                    FaceCount = defaultFace.Length;
                                    Console.WriteLine("FaceCount : " + FaceCount);
                                    _capture.Stop();
                                }

                            }
                        }

        */
                    #endregion


                    #endregion
                }
                AppLogger.Info("ProcessFrame end");
            }
            catch (Exception e)
            {
                AppLogger.Error("ProcessFrame", e);
            }
            ///flag based stopping
            //_capture.Dispose();
            //_capture = null;
        }

        public async void StopDetection()
        {

            AppLogger.Info("StopDetection start");
            try
            {

                var spaceAvailable=ViewModelLocator.MainVM.LiftMaxCount- Convert.ToInt32(peopleCount);
                ViewModelLocator.MainVM.FaceCount = spaceAvailable;
                ViewModelLocator.MainVM.CountButtonEnabled = true;

                
                
                await Task.Delay(200);
                Messenger.Default.Send<CapturedImageMessage>(new CapturedImageMessage()
                {
                    ImagePath = CapturedImage
                });
                AppLogger.Info(peopleCount.ToString());

                //  foreach (var o in FaceCounts)
                // {
                //     AppLogger.Info(o.ToString());
                // }


                // AppLogger.Info("Average:" + ViewModelLocator.MainVM.FaceCount);
                _capture.Stop();
                _capture.Dispose();
                _capture = null;
            }
            catch (Exception e)
            {
                AppLogger.Error("StopDetection start", e);
            }

            AppLogger.Info("StopDetection end");
        }

        private object GetValidFace(Rectangle[] faces, Rectangle[] faces1, Rectangle[] faces2)
        {

            //        4           5                                  7
            //return (faces.Length > faces1.Length ? (faces.Length > faces2.Length ? faces : faces2) : (faces1.Length);
            return null;
        }
    }


}
