﻿using Microsoft.ProjectOxford.Vision;
using Microsoft.ProjectOxford.Vision.Contract;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartElevators.Business
{
   public class UploadImage
    {
        public async Task<AnalysisResult> UploadAndAnalyzeImage(string imageFilePath= @"C:\ProgramData\Pelco\OpsCenter\Plugins\SmartElevator\CapturedImages\01-16-201701dd8ceb-5805-40e5-bc78-fa89c2e477c9.bmp")
        {
            //
            // Create Project Oxford Computer Vision API Service client
            //
            VisionServiceClient VisionServiceClient = new VisionServiceClient("f748d5bfb1dd40518d646e26dc98cb61");


            using (Stream imageFileStream = File.OpenRead(imageFilePath))
            {
                //
                // Analyze the image for all visual features
                //
                // Log("Calling VisionServiceClient.AnalyzeImageAsync()...");
                VisualFeature[] visualFeatures = new VisualFeature[] { VisualFeature.Faces ,VisualFeature.Description};
                AnalysisResult analysisResult = await VisionServiceClient.AnalyzeImageAsync(imageFileStream, visualFeatures);
                return analysisResult;
            }
        }
    }
}
