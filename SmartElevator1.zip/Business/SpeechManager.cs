﻿using SmartElevators.ViewModel;
using System;
using System.Speech.Recognition;

namespace GestureControl.Capabilities.Speech
{
    class SpeechManager
    {
        SpeechRecognitionEngine engine = new SpeechRecognitionEngine();
        private SpeechManager()
        {
           // ToggleSpeechCapability(true);
        }

        public void Initialise()
        {
            try
            {
                Choices commands = new Choices();
                commands.Add(new string[] { "help", "Emergency"});
                GrammarBuilder grmrBuildr = new GrammarBuilder();
                grmrBuildr.Append(commands);
                Grammar grmr = new Grammar(grmrBuildr);

                engine.LoadGrammarAsync(grmr);
                engine.SetInputToDefaultAudioDevice();
                engine.SpeechRecognized += Engine_SpeechRecognized;
            }catch(Exception e)
            {
                ViewModelLocator.MainVM.ErrorMsg = "Error!";
            }
        }
        

        private void Engine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            try
            {
                switch (e.Result.Text)
                {
                    case "help":
                        SmartElevators.ViewModel.ViewModelLocator.MainVM.IsEmergencyActivated = true;
                        SmartElevators.ViewModel.ViewModelLocator.MainVM.ErrorMsg = "Help";
                        break;
                    case "Emergency":
                        //   ViewModel.ViewModelLocator.MainVM.VoiceMessage = "Right";
                        SmartElevators.ViewModel.ViewModelLocator.MainVM.IsEmergencyActivated = true;
                        SmartElevators.ViewModel.ViewModelLocator.MainVM.ErrorMsg = "Emergency";
                        break;
                    case "one":                 //   ViewModel.ViewModelLocator.MainVM.VoiceMessage = "Top";

                    case "two":                  //  ViewModel.ViewModelLocator.MainVM.VoiceMessage = "Bottom";

                    case "three":                  //  ViewModel.ViewModelLocator.MainVM.VoiceMessage = "In";

                    case "four":                  //  ViewModel.ViewModelLocator.MainVM.VoiceMessage = "Out";

                    default:
                        break;
                }
            }catch(Exception)
            {
                ViewModelLocator.MainVM.ErrorMsg = "Error!";
            }
        }

        private static SpeechManager speechEngineInstance;
        public static SpeechManager Instance
        {
            get
            {
                if (speechEngineInstance == null)
                {
                    speechEngineInstance = new SpeechManager();
                }
                return speechEngineInstance;
            }
        }

        public void ToggleSpeechCapability(bool shouldListenSpeech)
        {
            try
            {
                if (shouldListenSpeech)
                {
                    engine.RecognizeAsync(RecognizeMode.Multiple);
                }
                else
                {
                    engine.RecognizeAsyncStop();
                }
            }catch(Exception e)
            {
                ViewModelLocator.MainVM.ErrorMsg = "Error!";
            }
        }
    }
}
