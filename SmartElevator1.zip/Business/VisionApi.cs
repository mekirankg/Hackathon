﻿using System;
using System.Text;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Web;
//using Microsoft.ProjectOxford.Vision;
//using Microsoft.ProjectOxford.Vision.Contract;
using System.Threading.Tasks;
using System.IO;
using Microsoft.ProjectOxford.Vision.Contract;

namespace SmartElevators.Business
{


    public static class VisionApi
    {
        //   static void Main()
        //  {
        //      MakeRequest();
        //      Console.WriteLine("Hit ENTER to exit...");
        //      Console.ReadLine();
        //   }

        public static async void MakeRequest()
        {
            var client = new HttpClient();
            var queryString = HttpUtility.ParseQueryString(string.Empty);

            // Request headers
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "f748d5bfb1dd40518d646e26dc98cb61");

            // Request parameters
            queryString["visualFeatures"] = "Categories";
            queryString["details"] = "{string}";
            queryString["language"] = "en";
            var uri = "https://westus.api.cognitive.microsoft.com/vision/v1.0/analyze?" + queryString;

            HttpResponseMessage response;

            // Request body
            byte[] byteData = Encoding.UTF8.GetBytes(@"C:\ProgramData\Pelco\OpsCenter\Plugins\SmartElevator\CapturedImages\myimage.bmp");

            using (var content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                response = await client.PostAsync(uri, content);
            }

        }



        

    }
}
