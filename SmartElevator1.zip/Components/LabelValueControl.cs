﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace SmartElevators.Components
{

    /// <summary>
    /// Control that can be binded to show a text and its corresponding value.
    /// Exposes two Custom bindings "LabelText" and "Value" to bind a key Value pair    
    /// </summary>
public class LabelValueControl : Control
{
    public static readonly DependencyProperty LabelTextProperty = DependencyProperty.Register(
        "LabelText",
        typeof(string),
        typeof(LabelValueControl),
        new PropertyMetadata(default(string)));

    public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
        "Value",
        typeof(string),
        typeof(LabelValueControl),
        new FrameworkPropertyMetadata
        {
            DefaultValue = string.Empty,
            BindsTwoWayByDefault = true,
            DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
        });

    public static readonly DependencyProperty PlaceHolderProperty = DependencyProperty.Register(
      "Placeholder",
      typeof(bool),
      typeof(LabelValueControl),
      new FrameworkPropertyMetadata
      {
          DefaultValue = false,
          BindsTwoWayByDefault = true,
          DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
      });



    static LabelValueControl()
    {
        DefaultStyleKeyProperty.OverrideMetadata(typeof(LabelValueControl), new FrameworkPropertyMetadata(typeof(LabelValueControl)));
    }

    public string LabelText
    {
        get
        {
            return (string)GetValue(LabelTextProperty);
        }
        set
        {
            SetValue(LabelTextProperty, value);
        }
    }

    public string Value
    {
        get
        {
            return (string)GetValue(ValueProperty);
        }
        set
        {
            SetValue(ValueProperty, value);
        }
    }
    public bool PlaceHolder
    {
        get
        {
            return (bool)GetValue(PlaceHolderProperty);
        }
        set
        {
            SetValue(PlaceHolderProperty, value);
        }
    }
}
}
