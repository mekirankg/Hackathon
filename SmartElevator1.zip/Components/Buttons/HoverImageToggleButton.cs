﻿using System;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace SmartElevators.Components.Buttons
{
    /// <summary>
    /// Toggle Button that can show 4 different images based on toggle/hover states.
    /// </summary>
    public class HoverImageToggleButton : ToggleButton
    {
        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
        }

        #region Properties

        public static readonly DependencyProperty NormalImageProperty = DependencyProperty.Register(
            "NormalImage",
            typeof(ImageSource),
            typeof(HoverImageToggleButton),
            new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Image shown when button is not checked or hovered over.
        /// </summary>
        public ImageSource NormalImage
        {
            get { return (ImageSource)GetValue(NormalImageProperty); }
            set { SetValue(NormalImageProperty, value); }
        }

        public static readonly DependencyProperty HoverImageProperty = DependencyProperty.Register(
            "HoverImage",
            typeof(ImageSource),
            typeof(HoverImageToggleButton),
            new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Image shown when button is hovered over but not checked.
        /// </summary>
        public ImageSource HoverImage
        {
            get { return (ImageSource)GetValue(HoverImageProperty); }
            set { SetValue(HoverImageProperty, value); }
        }

        public static readonly DependencyProperty CheckedImageProperty = DependencyProperty.Register(
            "CheckedImage",
            typeof(ImageSource),
            typeof(HoverImageToggleButton),
            new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Image shown when button is checked but not hovered over.
        /// </summary>
        public ImageSource CheckedImage
        {
            get { return (ImageSource)GetValue(CheckedImageProperty); }
            set { SetValue(CheckedImageProperty, value); }
        }

        public static readonly DependencyProperty CheckedHoverImageProperty = DependencyProperty.Register(
            "CheckedHoverImage",
            typeof(ImageSource),
            typeof(HoverImageToggleButton),
            new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Image shown when button is checked and hovered over.
        /// </summary>
        public ImageSource CheckedHoverImage
        {
            get { return (ImageSource)GetValue(CheckedHoverImageProperty); }
            set { SetValue(CheckedHoverImageProperty, value); }
        }

        public static readonly DependencyProperty PressedImageProperty = DependencyProperty.Register(
            "PressedImage",
            typeof(ImageSource),
            typeof(HoverImageToggleButton),
            new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Image shown when button is unchecked and pressed.
        /// </summary>
        public ImageSource PressedImage
        {
            get { return (ImageSource)GetValue(PressedImageProperty); }
            set { SetValue(PressedImageProperty, value); }
        }

        public static readonly DependencyProperty CheckedPressedImageProperty = DependencyProperty.Register(
            "CheckedPressedImage",
            typeof(ImageSource),
            typeof(HoverImageToggleButton),
            new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Image shown when button is checked and pressed.
        /// </summary>
        public ImageSource CheckedPressedImage
        {
            get { return (ImageSource)GetValue(CheckedPressedImageProperty); }
            set { SetValue(CheckedPressedImageProperty, value); }
        }

        #endregion //Properties
    }
}
