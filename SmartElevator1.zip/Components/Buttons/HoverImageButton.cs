﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SmartElevators.Components.Buttons
{
    /// <summary>
    /// A standard button that contains two DependencyProperties that hold the normal image and the hover image which can then be binded to in styles and triggers.
    /// </summary>
    public class HoverImageButton : Button
    {
        #region NormalImage
        public static readonly DependencyProperty NormalImageProperty = DependencyProperty.Register("NormalImage",
            typeof(ImageSource), typeof(HoverImageButton), new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Normal image to dislpay when the button is not in any other state.
        /// </summary>
        public ImageSource NormalImage
        {
            get { return (ImageSource)GetValue(NormalImageProperty); }
            set { SetValue(NormalImageProperty, value); }
        }
        #endregion

        #region HoverImage
        public static readonly DependencyProperty HoverImageProperty = DependencyProperty.Register("HoverImage",
            typeof(ImageSource), typeof(HoverImageButton), new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Image to display when the mouse is over the button.
        /// </summary>
        public ImageSource HoverImage
        {
            get { return (ImageSource)GetValue(HoverImageProperty); }
            set { SetValue(HoverImageProperty, value); }
        }
        #endregion

        #region DisabledImage
        public static readonly DependencyProperty DisabledImageProperty = DependencyProperty.Register("DisabledImage",
            typeof(ImageSource), typeof(HoverImageButton), new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Optional image to display when the button is disabled.
        /// </summary>
        public ImageSource DisabledImage
        {
            get { return (ImageSource)GetValue(DisabledImageProperty); }
            set { SetValue(DisabledImageProperty, value); }
        }
        #endregion

        #region PressedImage
        public static readonly DependencyProperty PressedImageProperty = DependencyProperty.Register("PressedImage",
            typeof(ImageSource), typeof(HoverImageButton), new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Optional image to display when the button is pressed or active.
        /// </summary>
        public ImageSource PressedImage
        {
            get { return (ImageSource)GetValue(PressedImageProperty); }
            set { SetValue(PressedImageProperty, value); }
        }
        #endregion

        #region FocusedImage
        public static readonly DependencyProperty FocusedImageProperty = DependencyProperty.Register("FocusedImage",
            typeof(ImageSource), typeof(HoverImageButton), new FrameworkPropertyMetadata(null));

        /// <summary>
        /// 
        /// </summary>
        public ImageSource FocusedImage
        {
            get { return (ImageSource)GetValue(FocusedImageProperty); }
            set { SetValue(FocusedImageProperty, value); }
        }
        #endregion
    }
}
