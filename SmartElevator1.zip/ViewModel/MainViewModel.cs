#region Namespaces
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

using SmartElevators.Utils;
using Pelco.Phoenix.PluginHostInterfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Media.Imaging;
using SmartElevators.Messaging;
using GalaSoft.MvvmLight.Messaging;
using System.Windows.Threading;
using System.Threading.Tasks;
using SmartElevators.Business;
using Microsoft.ProjectOxford.Vision.Contract;
using GestureControl.Capabilities.Speech;
using System.Linq;
using SmartElevators.Service;
using SmartElevators.Models;
using System.Windows;
#endregion

namespace SmartElevators.ViewModel
{
    /// <summary>
    ///  Holds exposed properties & presentation logic of MainUserControl.
    /// </summary>
    public partial class MainViewModel : ViewModelBase
    {

        public MainViewModel()
        {
            Messenger.Default.Register<CapturedImageMessage>(this, (msg) => SetCapturedImage(msg));
            StartPeopleCountCommand = new RelayCommand(RefereshCount);
            StartVoiceCommand = new RelayCommand(StartVoiceRecognition);
            Initialize();
            var configdata = ConfigurationManager.GetDBConfigurationDetails();
            FaceCount = configdata.LiftMaxCount;
            AdvIp = configdata;
            LiftMaxCount= configdata.LiftMaxCount;
        }

        public RelayCommand StartPeopleCountCommand { get; set; }

        public RelayCommand StartVoiceCommand { get; set; }

        private int faceCount = 0;
        public int maleCount;

        public int MaleCount
        {
            get { return maleCount; }
            set
            {
                maleCount = value;
                RaisePropertyChanged("MaleCount");
            }
        }

        public ConfigurationData AdvIp { get; set; }

        public int LiftMaxCount { get; set; }

        public int femaleCount;

        public int FemaleCount
        {
            get { return femaleCount; }
            set
            {
                femaleCount = value;
                RaisePropertyChanged("FemaleCount");
            }
        }

        public int averageAge;

        public int AverageAge
        {
            get { return averageAge; }
            set
            {
                averageAge = value;
                RaisePropertyChanged("AverageAge");
            }
        }
        public int FaceCount
        {
            get { return faceCount; }
            set { faceCount = value;
                RaisePropertyChanged("FaceCount");
            }
        }
        
        private string errorMsg = string.Empty;

        private bool isEmergencyActivated = false;

        public bool IsEmergencyActivated
        {
            get { return isEmergencyActivated; }
            set
            {
                isEmergencyActivated = value;
                RaisePropertyChanged("IsEmergencyActivated");
                if(value==true)
                {
                    ClearEmergency();
                }
            }
        }

        private async void ClearEmergency()
        {
            await Task.Delay(5000);
            IsEmergencyActivated = false;
            SmartElevators.ViewModel.ViewModelLocator.MainVM.ErrorMsg = string.Empty;
        }

        public string ErrorMsg
        {
            get { return errorMsg; }
            set
            {
                errorMsg = value;
                RaisePropertyChanged("ErrorMsg");
            }
        }

        private bool countButtonEnabled = true;

        public bool CountButtonEnabled
        {
            get { return countButtonEnabled; }
            set
            {
                countButtonEnabled = value;
                RaisePropertyChanged("CountButtonEnabled");
            }
        }

        private bool voiceButtonEnabled = true;

        public bool VoiceButtonEnabled
        {
            get { return voiceButtonEnabled; }
            set
            {
                voiceButtonEnabled = value;
                RaisePropertyChanged("VoiceButtonEnabled");
            }
        }

        

        private string camIP = string.Empty;

        public string CamIP
        {
            get { return camIP; }
            set
            {
                camIP = value;
                RaisePropertyChanged("CamIP");
            }
        }

        private BitmapImage frameImage = new BitmapImage(); 

        public BitmapImage FrameImage
        {
            get { return frameImage; }
            set
            {
                frameImage = value;
                RaisePropertyChanged("FrameImage");
            }
        }

        private async void SetCapturedImage(CapturedImageMessage msg)
        {
            try
            {
                MaleCount = 0;
                FemaleCount = 0;
                AverageAge = 0;
                if (msg.ImagePath==null)
                {
                    FrameImage = new BitmapImage();                    
                    return;
                }
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(msg.ImagePath);
                bitmap.EndInit();
                bitmap.Freeze();
                Dispatcher.CurrentDispatcher.Invoke(() => FrameImage = bitmap);
                AnalysisResult result = await new UploadImage().UploadAndAnalyzeImage(msg.ImagePath);
                var Masked = result.Description.Captions.FirstOrDefault(c => c.Text.ToLower().Contains("sun"));
                if (Masked != null)
                {
                    ErrorMsg = "Mask detected";
                    IsEmergencyActivated = true;
                }

                List<int> age = new List<int>();
                foreach (var face in result.Faces)
                {
                    if (face.Gender.ToLower() == "male")
                    {
                        MaleCount++;
                    }
                    else
                    {
                        FemaleCount++;
                    }
                    age.Add(face.Age);
                }

                AverageAge = Convert.ToInt32(age.Average());

             //   if(result.Faces.Count()>FaceCount)
                {
                    FaceCount = AdvIp.LiftMaxCount - result.Faces.Count();
                }

                if(AverageAge<20)
                {
                    var ip = AdvIp.AdvChild;
                    await StreamCameraInMonitor(ip);
                }
                else if(MaleCount>FemaleCount)
                {
                    var ip = AdvIp.AdvMen;
                  await StreamCameraInMonitor(ip);
                }
                else
                {
                    var ip = AdvIp.AdvWomen;
                  await StreamCameraInMonitor(ip);
                }


            }
            catch(Exception e)
            {
                AppLogger.ErrorException(e);
            }
        }


        public async void RefereshCount()
        {
            AppLogger.Info("RefereshCount start");

          //  while (true)
          //  {
                try
                {
                    CountButtonEnabled = false;
                    var faceCtr = new FaceCounter();
                    var configdata = ConfigurationManager.GetDBConfigurationDetails();
                    LiftMaxCount = configdata.LiftMaxCount;
                    var camstring = "rtsp://" + configdata.IP + "/stream1";

                    var status = faceCtr.StartDetection(camstring);
                    if (!status)
                    {
                        AppLogger.Error("Start Detection failed");
                        ViewModelLocator.MainVM.ErrorMsg = "Start Detection failed";
                        //  continue;
                    }
                    else
                    {
                        ErrorMsg = "";
                    }

                    await Task.Delay(3000);
                    faceCtr.StopDetection();
                    await Task.Delay(300);
                }
                catch (Exception ex)
                {
                    AppLogger.Error("InitializeSmartElevator", ex);
                }
           // }

            AppLogger.Info("RefereshCount end");

        }

        public async void RequestDetails()
        {
            // VisionApi.MakeRequest();
            await new UploadImage().UploadAndAnalyzeImage();
        }

        public void StartVoiceRecognition()
        {
            VoiceButtonEnabled = false;
            SpeechManager.Instance.Initialise();
            SpeechManager.Instance.ToggleSpeechCapability(true);
        }

        public async void Initialize()
        {
           await CommunicationManager.Instance.Initialise();
           await LoadCameras();
          //  await GetMonitors();
            //Messenger.Default.Send<GestureCameraStreamMessage>(new Messages.GestureCameraStreamMessage() { FingureGestureCount = 1 });


        }

        /// <summary>
        /// Loads the cameras from the server.
        /// </summary>
        public async Task LoadCameras()
        {
            try
            {
                AppLogger.Trace("CameraManager.LoadCameras() -Begin");
                //var mainVM = ViewModelLocator.MainVM;
                var CamerasCache = await CommunicationManager.Instance.GetCamerasAsync();
                if (CamerasCache != null)
                {
                    CameraCache.Instance.AllCameras = new ObservableCollection<CameraData>();
                    foreach (var item in CamerasCache.data_sources)
                    {
                        if (CameraCache.Instance.AllCameras.Any(x => x.Id == item.id))
                        {
                            continue;
                        }

                        CameraData cam = new CameraData()
                        {
                            Id = item.id,
                            Name = item.name
                        };

                        if (item._embedded != null &&
                            item._embedded.device != null &&
                            !string.IsNullOrWhiteSpace(item._embedded.device.model) &&
                            item._embedded.device.model.ToLower().Contains("imm"))
                        {
                            string opteraIndicator = item._embedded.device.model.Substring(6, 2);
                            switch (opteraIndicator)
                            {
                                case "18":
                                    cam.CamType = CameraType.Immersive_180;
                                    break;
                                case "27":
                                    cam.CamType = CameraType.Immersive_270;
                                    break;
                                case "36":
                                    cam.CamType = CameraType.Immersive_360;
                                    break;
                                default:
                                    break;
                            }
                        }
                        else if (item._links != null && item._links.ptz_controller != null)
                        {
                            cam.CamType = CameraType.PTZ;
                        }
                        else
                        {
                            cam.CamType = CameraType.Fixed;
                        }

                        cam.IPAddress = item.ip;
                        cam.Number = item.number;
                        cam.LinkInfo = item._links;
                        cam.DeviceInfo = (item._embedded == null) ? null : item._embedded.device;
                        cam.IsOnline = item.state.ToLower() == "online";
                        cam.Type = item.type;
                        cam.IsRecording = item.recording;
                        cam.SnapshotURL = (item._links != null) ? item._links.snapshot : string.Empty;
                        cam.CanDisplaySnapshot = !string.IsNullOrEmpty(cam.SnapshotURL);
                        CameraCache.Instance.AllCameras.Add(cam);
                    }
                }

                AppLogger.Info("Cameras Count:" + CameraCache.Instance.AllCameras.Count().ToString());
                AppLogger.Trace("CameraManager.LoadCameras() -End");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Message:" + ex.Message + "\nStack Trace: " + ex.StackTrace);
            }
        }

        public async Task GetMonitors()
        {
            var MonitorCache = await CommunicationManager.Instance.GetMonitorsAsync();          
            var camera = CameraCache.Instance.AllCameras.FirstOrDefault(c => c.IPAddress == "10.1.26.31");
            var monitor = MonitorCache.monitors.FirstOrDefault(m => m.name.ToLower() == "smartelevator");
            var cell = monitor.cells.FirstOrDefault(i=>i.index==1);
            var updatedCell = new UpdateMonitorCell();
            updatedCell.data_source_id = camera.Id;
            updatedCell.speed = 1;//450c8982-f71c-368a-91d0-07f0a8829c04
            updatedCell.time = null;

            await CommunicationManager.Instance.EditMonitorCell(updatedCell, cell._links.edit);
        }

        public async Task StreamCameraInMonitor(string ip)
        {
            var MonitorCache = await CommunicationManager.Instance.GetMonitorsAsync();
            var camera = CameraCache.Instance.AllCameras.FirstOrDefault(c => c.IPAddress == ip);
            var monitor = MonitorCache.monitors.FirstOrDefault(m => m.name.ToLower() == AdvIp.MonitorName.ToLower());
            var cell = monitor.cells.FirstOrDefault(i => i.index == 1);
            var updatedCell = new UpdateMonitorCell();
            updatedCell.data_source_id = camera.Id;
            updatedCell.speed = 1;
            updatedCell.time = null;

            await CommunicationManager.Instance.EditMonitorCell(updatedCell, cell._links.edit);
        }
    }
}