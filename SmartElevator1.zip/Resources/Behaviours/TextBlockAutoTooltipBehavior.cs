﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SmartElevators.Resources.Behaviours
{
    /// <summary>
    /// This behavior will set the tooltip of a textblock if the text is being trimmed.
    /// </summary>
    public class TextBlockAutoTooltipBehavior : MemorySafeBehavior<TextBlock>
    {
        protected override void OnSetup()
        {
            if (AssociatedObject.TextTrimming == TextTrimming.None)
            {
                AssociatedObject.TextTrimming = TextTrimming.CharacterEllipsis;
            }
            AssociatedObject.SizeChanged += AssociatedObject_SizeChanged;                
        }

        protected override void Initialize()
        {
            ComputeAutoTooltip();
        }

        protected override void OnCleanup()
        {
            AssociatedObject.SizeChanged -= AssociatedObject_SizeChanged;
        }

        /// <summary>
        /// Called when tooltip size has changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void AssociatedObject_SizeChanged(object sender, System.Windows.SizeChangedEventArgs e)
        {
            ComputeAutoTooltip();
        }

        /// <summary>
        /// Assigns the ToolTip for the given TextBlock based on whether the text is trimmed
        /// </summary>
        private void ComputeAutoTooltip()
        {
            TextBlock textBlock = AssociatedObject;
            if (textBlock.TextTrimming == TextTrimming.None)
            {
                return;
            }
            textBlock.Measure(new Size(Double.PositiveInfinity, Double.PositiveInfinity));
            double desiredWidth = textBlock.DesiredSize.Width;
            // We must remove margins from desired width since ActualWidth does not include them.
            if (!Double.IsNaN(textBlock.Margin.Left))
            {
                desiredWidth -= textBlock.Margin.Left;
            }
            if (!Double.IsNaN(textBlock.Margin.Right))
            {
                desiredWidth -= textBlock.Margin.Right;
            }
            if (textBlock.ActualWidth < desiredWidth)
            {
                ToolTipService.SetToolTip(textBlock, textBlock.Text);
            }
            else
            {
                ToolTipService.SetToolTip(textBlock, null);
            }
        }
    }
}
