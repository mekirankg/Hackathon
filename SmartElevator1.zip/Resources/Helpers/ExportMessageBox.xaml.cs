﻿using System;
using System.Timers;
using System.Windows;
using System.Windows.Input;

namespace SmartElevators.Resources.Helpers
{
    /// <summary>
    /// Interaction logic for CustomMessageBox.xaml
    /// </summary>
    public partial class ExportMessageBox : Window
    {
        public enum ButtonClicked {
            None,
            Button1,
            Button2
        }

        public ButtonClicked buttonClicked = ButtonClicked.None;

        public ExportMessageBox(string button1Text, Boolean autoClose, string button2Text = "")
        {
            InitializeComponent();
            NameText.Focus();
			this.Topmost = true;     
            if (autoClose)
                this.Loaded += ExportMessageBox_Loaded;          
            this.button1.Content = button1Text;            
            if (String.IsNullOrEmpty(button2Text))
            {
                button2.Visibility = System.Windows.Visibility.Hidden;
            }
            else
                button2.Content = button2Text;
            
        }


        void ExportMessageBox_Loaded(object sender, RoutedEventArgs e)
        {
            Timer t = new Timer();
            t.Interval = 3000;
            t.Elapsed += new ElapsedEventHandler(t_Elapsed);
            t.Start();
        }

        void t_Elapsed(object sender, ElapsedEventArgs e)
        {
            this.Dispatcher.Invoke(new Action(() =>
            {
                this.Close();
            }), null);
        }

        public static string executerName;
        public static string testSummery;
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            buttonClicked = ButtonClicked.Button1;
            executerName = NameText.Text;
            testSummery = Summery.Text;               
           
            this.Dispatcher.Invoke(new Action(() =>
            {
                this.Close();
            }), null);
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            buttonClicked = ButtonClicked.Button2;
            this.Dispatcher.Invoke(new Action(() =>
            {
                this.Close();
            }), null);
        }

        private void Summery_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (NameText.Text != "" & Summery.Text != "")
            {
                executerName = NameText.Text;
                testSummery = Summery.Text;
                this.button1.IsEnabled = true;
            }
            else
            {
                this.button1.IsEnabled = false;
            }
          
        }

        private void NameText_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (NameText.Text != "" & Summery.Text != "")
            {
                executerName = NameText.Text;
                testSummery = Summery.Text;
                this.button1.IsEnabled = true;
            }
            else
            {
                this.button1.IsEnabled = false;
            }
        }
    }
}
