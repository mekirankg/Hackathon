﻿using System;
using System.Timers;
using System.Windows;

namespace SmartElevators.Resources.Helpers
{
    /// <summary>
    /// Interaction logic for CustomMessageBox.xaml
    /// </summary>
    public partial class CustomMessageBox : Window
    {
        public enum ButtonClicked {
            None,
            Button1,
            Button2
        }

        public ButtonClicked buttonClicked = ButtonClicked.None;

        public CustomMessageBox(string label, string button1Text, Boolean autoClose, string title, string button2Text = "")
        {
            InitializeComponent();
			this.Topmost = true;
            if (autoClose)
                this.Loaded += CustomMessageBox_Loaded;

            this.label1.Text = label;
            this.button1.Content = button1Text;
            this.title1.Content = title;
            if (String.IsNullOrEmpty(button2Text))
            {
                // CMBGrid.Children.Remove(button2);
                button2.Visibility = System.Windows.Visibility.Hidden;
            }

            else
                button2.Content = button2Text;
            
        }


        void CustomMessageBox_Loaded(object sender, RoutedEventArgs e)
        {
            Timer t = new Timer();
            t.Interval = 3000;
            t.Elapsed += new ElapsedEventHandler(t_Elapsed);
            t.Start();
        }

        void t_Elapsed(object sender, ElapsedEventArgs e)
        {
            this.Dispatcher.Invoke(new Action(() =>
            {
                this.Close();
            }), null);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            buttonClicked = ButtonClicked.Button1;
            this.Dispatcher.Invoke(new Action(() =>
            {
                this.Close();
            }), null);
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            buttonClicked = ButtonClicked.Button2;
            this.Dispatcher.Invoke(new Action(() =>
            {
                this.Close();
            }), null);
        }
    }
}
