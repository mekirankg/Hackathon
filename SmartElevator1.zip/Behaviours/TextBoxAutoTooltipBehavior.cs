﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SmartElevators.Behaviours
{
    /// <summary>
    /// This behavior will set the tooltip of a textblock if the text is being trimmed.
    /// </summary>
    public class TextBoxAutoTooltipBehavior : MemorySafeBehavior<TextBox>
    {
        protected override void OnSetup()
        {
            if (AssociatedObject.TextWrapping != TextWrapping.NoWrap)
            {
                AssociatedObject.TextWrapping = TextWrapping.NoWrap;
            }
            AssociatedObject.SizeChanged += AssociatedObject_SizeChanged;                
        }

        protected override void Initialize()
        {
            ComputeAutoTooltip();
        }

        protected override void OnCleanup()
        {
            AssociatedObject.SizeChanged -= AssociatedObject_SizeChanged;
        }

        /// <summary>
        /// Called when tooltip size has changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void AssociatedObject_SizeChanged(object sender, System.Windows.SizeChangedEventArgs e)
        {
            ComputeAutoTooltip();
        }

        /// <summary>
        /// Assigns the ToolTip for the given TextBlock based on whether the text is trimmed
        /// </summary>
        private void ComputeAutoTooltip()
        {
            TextBox textBox = AssociatedObject;

            textBox.Measure(new Size(Double.PositiveInfinity, Double.PositiveInfinity));
            double desiredWidth = textBox.DesiredSize.Width;
            // We must remove margins from desired width since ActualWidth does not include them.
            if (!Double.IsNaN(textBox.Margin.Left))
            {
                desiredWidth -= textBox.Margin.Left;
            }
            if (!Double.IsNaN(textBox.Margin.Right))
            {
                desiredWidth -= textBox.Margin.Right;
            }
            if (textBox.ActualWidth < desiredWidth)
            {
                ToolTipService.SetToolTip(textBox, textBox.Text);
            }
            else
            {
                ToolTipService.SetToolTip(textBox, null);
            }
        }
    }
}
