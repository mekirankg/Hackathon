﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartElevators.Models
{
   public class ConfigurationData
    {
        public string IP { get; set; }
        public int LiftMaxCount { get; set; }
        public string AdvMen { get; set; }
        public string AdvWomen { get; set; }
        public string AdvChild { get; set; }
        public string AdvCommon { get; set; }

        public string MonitorName { get; set; }

    }
}
