﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartElevators.Models
{
    public class CameraCache
    {
        static CameraCache cameraCache;
        public static CameraCache Instance
        {
            get { return cameraCache; }
        }
        static CameraCache()
        {
            cameraCache = new Models.CameraCache();
        }
        private CameraCache()
        {
        }
        private ObservableCollection<CameraData> allCameras;
        public ObservableCollection<CameraData> AllCameras
        {
            get { return allCameras; }
            set
            {
                allCameras = value;
            }
        }
    }
}
