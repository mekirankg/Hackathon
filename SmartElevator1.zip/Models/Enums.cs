﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartElevators.Models
{
    public enum CameraType
    {
        PTZ = 1,
        Fixed = 2,
        Immersive_180 = 3,
        Immersive_270 = 4,
        Immersive_360 = 5
    }
}
