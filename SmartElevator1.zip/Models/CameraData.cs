﻿using SmartElevators.Service;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace SmartElevators.Models
{
    public class CameraData : ModelBase
    {
        #region Private Fields
        private bool _CanDisplaySnapshot;

        private double _CenterX;

        private double _CenterY;
        private string _Id;

        private string _IPAddress;

        private bool _IsEditSelected;

        private bool _IsInAlarmMode;

        private bool _IsMappedInCurrentMap;

        private bool _IsMultiSelected;

        private bool? _IsOnline;

        private bool _IsOnScreen;

        private bool? _IsPTZLocked;

        private bool? _IsRecording;

        private bool _IsSnapshotBeingLoaded;

        private string _Name;

        private bool _NeedAttention;

        private int _Number;
        //  private double _RotateAngle;

        private BitmapSource _SnapshotImage;

        private ObservableCollection<string> assignedTags;
        #endregion

        #region Properties
        public CameraType _CamType;        
        public ObservableCollection<string> AssignedTags
        {
            get
            {
                return assignedTags;
            }
            set
            {
                assignedTags = value;
                RaisePropertyChanged("AssignedTags");
            }
        }

        public string Id
        {
            get
            {
                return _Id;
            }
            set
            {
                _Id = value;
                RaisePropertyChanged("Id");
            }
        }

       
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
                RaisePropertyChanged("Name");
            }
        }

        public int Number
        {
            get
            {
                return _Number;
            }
            set
            {
                _Number = value;
                RaisePropertyChanged("Number");
            }
        }

       
        public string IPAddress
        {
            get
            {
                return _IPAddress;
            }
            set
            {
                _IPAddress = value;
                RaisePropertyChanged("IPAddress");
            }
        }

       
        public CameraType CamType
        {
            get
            {
                return _CamType;
            }
            set
            {
                _CamType = value;
                RaisePropertyChanged("CamType");
            }
        }

        public double CenterX
        {
            get
            {
                return _CenterX;
            }
            set
            {
                _CenterX = value;
                RaisePropertyChanged("CenterX");
            }
        }

        public double CenterY
        {
            get
            {
                return _CenterY;
            }
            set
            {
                _CenterY = value;
                RaisePropertyChanged("CenterY");
            }
        }
        //[JsonInclude("RotateAngle")]
        //public double RotateAngle
        //{
        //    get
        //    {
        //        return _RotateAngle;
        //    }
        //    set
        //    {
        //        _RotateAngle = value;
        //        RaisePropertyChanged("RotateAngle");
        //    }
        //}

        public bool IsMappedInCurrentMap
        {
            get
            {
                return _IsMappedInCurrentMap;
            }
            set
            {
                _IsMappedInCurrentMap = value;
                RaisePropertyChanged("IsMappedInCurrentMap");
            }
        }

       
        public bool IsEditSelected
        {
            get
            {
                return _IsEditSelected;
            }
            set
            {
                _IsEditSelected = value;
                RaisePropertyChanged("IsEditSelected");
            }
        }

        public bool IsMultiSelected
        {
            get
            {
                return _IsMultiSelected;
            }
            set
            {
                _IsMultiSelected = value;
                RaisePropertyChanged("IsMultiSelected");
            }
        }

       
        public bool IsOnScreen
        {
            get
            {
                return _IsOnScreen;
            }
            set
            {
                _IsOnScreen = value;
                RaisePropertyChanged("IsOnScreen");
            }
        }

       
        public bool? IsOnline
        {
            get
            {
                return _IsOnline;
            }
            set
            {
                _IsOnline = (value.HasValue) ? value : null;
                RaisePropertyChanged("IsOnline");
            }
        }

       
        public bool IsInAlarmMode
        {
            get
            {
                return _IsInAlarmMode;
            }
            set
            {
                _IsInAlarmMode = value;
                RaisePropertyChanged("IsInAlarmMode");
            }
        }

       
        public bool? IsRecording
        {
            get
            {
                return _IsRecording;
            }
            set
            {
                _IsRecording = (value.HasValue) ? value : null;
                RaisePropertyChanged("IsRecording");
            }
        }

       
        public bool? IsPTZLocked
        {
            get
            {
                return _IsPTZLocked;
            }
            set
            {
                _IsPTZLocked = (value.HasValue) ? value : null;
                RaisePropertyChanged("IsPTZLocked");
            }
        }

        public bool NeedAttention
        {
            get
            {
                return _NeedAttention;
            }
            set
            {
                _NeedAttention = value;
                RaisePropertyChanged("NeedAttention");
            }
        }

        public bool CanDisplaySnapshot
        {
            get
            {
                return _CanDisplaySnapshot;
            }
            set
            {
                _CanDisplaySnapshot = value;
                RaisePropertyChanged("CanDisplaySnapshot");
            }
        }

        public BitmapSource SnapshotImage
        {
            get
            {
                return _SnapshotImage;
            }
            set
            {
                if (_SnapshotImage != value)
                {
                    _SnapshotImage = value;
                    RaisePropertyChanged("SnapshotImage");
                }
            }
        }

        public bool IsSnapshotBeingLoaded
        {
            get
            {
                return _IsSnapshotBeingLoaded;
            }
            set
            {
                _IsSnapshotBeingLoaded = value;
                RaisePropertyChanged("IsSnapshotBeingLoaded");
            }
        }

        public string Type { get; set; }

      
        public string SnapshotURL { get; set; }
        public DataSourceAPILink LinkInfo { get; set; }
        public DeviceAPI DeviceInfo { get; set; }
        public MarkerAPI MarkerInfo { get; set; }

        #endregion

        #region Constructor

        public CameraData()
        {
            AssignedTags = new ObservableCollection<string>();
        }

        #endregion

        //public void AddTag(string tag)
        //{
        //    if (AssignedTags == null)
        //    {
        //        AssignedTags = new ObservableCollection<string>();
        //    }
        //    if (!AssignedTags.Contains(tag))
        //    {
        //        AssignedTags.Add(tag);
        //    }
        //}

    }
}
