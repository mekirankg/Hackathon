﻿
using SmartElevators.PluginAPI;
using SmartElevators.Resources.Helpers;
using SmartElevators.Resources.Lang;
using SmartElevators.Utils;
using SmartElevators.ViewModel;
using Pelco.Phoenix.PluginHostInterfaces;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Diagnostics;
using SmartElevators.Business;
using System.Threading.Tasks;

namespace SmartElevators.Views
{
    /// <summary>
    /// Interaction logic for MainUserControl.xaml
    /// </summary>
    public partial class MainUserControl : UserControl
    {
        #region Private Methods
       
        #endregion

        #region Properties       

        #endregion

        #region Constructor
        public MainUserControl()
        {
            InitializeComponent();
            DataContext = ViewModelLocator.MainVM;

#if DEBUG
            InitializeSmartElevator(null);
#endif

        }



        #endregion

        #region Public Methods
        public async void InitializeSmartElevator(PluginState stateInfo)
        {
            AppLogger.Info("InitializeSmartElevator start");
            try
            {

              //  await RefereshCount();
            }
            catch (Exception ex)
            {
                AppLogger.Error("InitializeSmartElevator", ex);
            }

            AppLogger.Info("InitializeSmartElevator End");
        }
       
        #endregion
    }
}
