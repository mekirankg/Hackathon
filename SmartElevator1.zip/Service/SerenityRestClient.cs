﻿using SmartElevators.Utils;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace SmartElevators.Service
{
    public class SerenityRestClient
    {
        private string authToken;
        private object headerAccessLockObject = new object();
        private Uri BaseUrl;

        internal string IP;
        internal int Port;
        internal string Scheme;
        private string serenityRequestContentType = string.Empty;
        public string serenityResponseContentType = string.Empty;
        private string serenitySystemVersion = string.Empty;

        public SerenityRestClient(string baseUri, string authTkn)
        {
            UriBuilder uriBldr = new UriBuilder(baseUri);
            IP = uriBldr.Host;
            Port = uriBldr.Port;
            Scheme = uriBldr.Scheme;
            BaseUrl = uriBldr.Uri;
            authToken = authTkn;

            ServicePointManager.ServerCertificateValidationCallback
                += (sender, certificate, chain, sslPolicyErrors) => true;
            ServicePointManager.DefaultConnectionLimit = 100;
            ServicePointManager.UseNagleAlgorithm = true;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.CheckCertificateRevocationList = true;
            ServicePointManager.MaxServicePointIdleTime = 5000;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;

            //this.Proxy = WebRequest.DefaultWebProxy;
            //this.Proxy.Credentials = CredentialCache.DefaultCredentials;
        }

        #region GET

        public async Task<T> GetSerenityResource<T>(string link, string acceptHeader)
        {
            HttpWebResponse webResponse = null;
            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(link);
                webRequest.Method = SerenityConstants.METHOD_GET;
                webRequest.Accept = acceptHeader;
                webRequest.UserAgent = SerenityConstants.USER_AGENT;
                webRequest.Credentials = CredentialCache.DefaultCredentials;
                SetUpAuthHeaders(webRequest);
                webResponse = (HttpWebResponse)(await webRequest.GetResponseAsync());

                if (typeof(T) == typeof(Tuple<Byte[], string>))
                {
                    using (Stream stream = webResponse.GetResponseStream())
                    {
                        string contentType = webResponse.ContentType;

                        Byte[] bytes = default(byte[]);
                        using (MemoryStream memstream = new MemoryStream())
                        {
                            await stream.CopyToAsync(memstream);
                            bytes = memstream.ToArray();
                        }
                        Tuple<Byte[], string> serByteArray = new Tuple<Byte[], string>(bytes, contentType);
                        return (T)Convert.ChangeType(serByteArray, typeof(T));
                    }
                }
                else
                {
                    using (StreamReader reader = new StreamReader(webResponse.GetResponseStream()))
                    {
                        String json = reader.ReadToEnd().
                        Replace("/pelco/rel/", "").
                        Replace("set_lock", "setlock").
                        Replace("set_image", "setimage").
                        Replace("set_heob", "setheob");
                        JavaScriptSerializer js = new JavaScriptSerializer();
                        js.MaxJsonLength = 30000000;
                        var obj = js.Deserialize<T>(json);
                        return obj;
                    }
                }
            }
            catch (WebException ex)
            {
                //LogCommunicationError(SerenityConstants.METHOD_GET, link, ex);

                var obj = (T)Activator.CreateInstance(typeof(T), new object[] { });
                var propertyName = obj.GetType().GetProperty("httpStatusCode");
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    var response = ex.Response as HttpWebResponse;

                    if (response != null)
                    {
                        if (typeof(T) == typeof(Tuple<Byte[], String, String>))
                        {
                            Tuple<Byte[], string, string> serByteArray = new Tuple<Byte[], String, String>
                                (null, null, ((int)response.StatusCode).ToString());
                            return (T)Convert.ChangeType(serByteArray, typeof(T));
                        }
                        else if (typeof(T) == typeof(Tuple<Byte[], String>))
                        {
                            Tuple<Byte[], string> serByteArray = new Tuple<Byte[], String>(null,
                                ((int)response.StatusCode).ToString());
                            return (T)Convert.ChangeType(serByteArray, typeof(T));

                        }
                        else
                        {
                            propertyName.SetValue(obj, ((int)response.StatusCode).ToString(), null);
                            return obj;
                        }
                    }
                }
                propertyName.SetValue(obj, "404", null);
                return obj;
            }
            catch (Exception ex)
            {
                //LogCommunicationError(SerenityConstants.METHOD_GET, link, ex);

                var obj = (T)Activator.CreateInstance(typeof(T), new object[] { });
                var propertyName = obj.GetType().GetProperty("httpStatusCode");
                propertyName.SetValue(obj, "404", null);
                return obj;
            }
            finally
            {
                if (webResponse != null)
                {
                    webResponse.Dispose();
                }
            }
        }

        #endregion
        private void SetUpAuthHeaders(HttpWebRequest req)
        {
            if (authToken != string.Empty)
            {
                req.Headers.Add(SerenityConstants.HEADER_COOKIE, String.Format("{0}={1}",
                    SerenityConstants.COOKIE_NAME_AUTHTOKEN, authToken));
            }
            else
            {
                var EncodedSerenityUser = Helper.Encode(System.Configuration.ConfigurationManager.AppSettings.Get("SerenityUser"));
                var EncodedSerenityPassword = Helper.Encode(System.Configuration.ConfigurationManager.AppSettings.Get("SerenityPassword"));
                req.Headers.Add(SerenityConstants.X_SERENITY_USER, EncodedSerenityUser);
                req.Headers.Add(SerenityConstants.X_SERENITY_PASSWORD, EncodedSerenityPassword);
                AppLogger.Info("Setting up auth header from configuration");
            }
        }

        public async Task<bool> PatchSerenityResource<T>(string link, T resource)
        {
            bool isPatchSuccess = false;
            HttpWebResponse webResponse = null;
            try
            {
                string data = new JavaScriptSerializer().Serialize(resource);

                HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create(link);
                webRequest.Method = SerenityConstants.METHOD_PATCH;
                webRequest.ContentLength = data.Length;
                webRequest.ContentType = SerenityConstants.CONTENT_TYPE_SERENITY_PATCH;
                webRequest.Accept = serenityResponseContentType;
                webRequest.Proxy = null;
                webRequest.Timeout = SerenityConstants.CONNECTION_TIMEOUT_IN_MS;
                webRequest.ServicePoint.MaxIdleTime = SerenityConstants.IDLE_TIMEOUT_IN_MS;
                SetUpAuthHeaders(webRequest);
                using (StreamWriter writer = new StreamWriter(await webRequest.GetRequestStreamAsync()))
                {
                    writer.Write(data);
                }
                webResponse = (HttpWebResponse)(await webRequest.GetResponseAsync());
                if (webResponse != null)
                {
                    int statusCode = (int)webResponse.StatusCode;
                    if ((statusCode >= 200 && statusCode < 300))
                    {
                        isPatchSuccess = true;
                    }
                }
            }
            catch (WebException ex)
            {

            }
            catch (Exception ex)
            {

            }
            return isPatchSuccess;
        }



        public async Task<HttpWebResponse> PostSerenityResource<T>(string link, T resource)
        {
            HttpWebResponse response = null;
            try
            {
                string data = new JavaScriptSerializer().Serialize(resource);

                HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create(link);
                webRequest.Method = SerenityConstants.METHOD_POST;
                webRequest.ContentLength = data.Length;
                webRequest.ContentType = SerenityConstants.CONTENT_TYPE_SERENITY_RESPONSE_ANY;
                webRequest.Accept = serenityResponseContentType;// APIConstants.CONTENT_TYPE_ANY_V3_0;
                webRequest.Proxy = null;
                webRequest.Timeout = SerenityConstants.CONNECTION_TIMEOUT_IN_MS;
                webRequest.ServicePoint.MaxIdleTime = SerenityConstants.IDLE_TIMEOUT_IN_MS;
                SetUpAuthHeaders(webRequest);

                using (StreamWriter writer = new StreamWriter(await webRequest.GetRequestStreamAsync()))
                {
                    writer.Write(data);
                }

                response = (HttpWebResponse)(await webRequest.GetResponseAsync());
            }
            catch (WebException ex)
            {
                
            }
            catch (Exception ex)
            {
                
            }

            return response;
        }

        public async Task<bool> PutSerenityResourceLocation<T>(string link, T resource)
        {
            bool isPostSuccess = false;
            HttpWebResponse response = null;
            try
            {
                string data1 = new JavaScriptSerializer().Serialize(resource);

                byte[] data = Encoding.ASCII.GetBytes(data1);

                HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create(link);
                webRequest.Method = SerenityConstants.METHOD_PUT;
                webRequest.ContentLength = data.Length;
                webRequest.ContentType = "application/octet-stream";
                webRequest.Accept = serenityResponseContentType;// APIConstants.CONTENT_TYPE_ANY_V3_0;
                webRequest.Proxy = null;
                webRequest.Timeout = SerenityConstants.CONNECTION_TIMEOUT_IN_MS;
                webRequest.ServicePoint.MaxIdleTime = SerenityConstants.IDLE_TIMEOUT_IN_MS;
                SetUpAuthHeaders(webRequest);

                using (BinaryWriter writer = new BinaryWriter(await webRequest.GetRequestStreamAsync()))
                {

                    writer.Write(data);
                }

                response = (HttpWebResponse)(await webRequest.GetResponseAsync());
                if (response != null)
                {
                    int statusCode = (int)response.StatusCode;
                    if ((statusCode >= 200 && statusCode < 300))
                    {
                        isPostSuccess = true;
                    }
                }
            }
            catch (WebException ex)
            {
                
                AppLogger.Error("Web exception thrown when POSTing resource", ex);
            }
            catch (Exception ex)
            {
                
                AppLogger.Error("Generic exception thrown when POSTing resource", ex);
            }
            return isPostSuccess;
        }


        public async Task<HttpWebResponse> PostSerenityResource(string link)
        {
            HttpWebResponse webResponse = null;
            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create(link);
                webRequest.Method = SerenityConstants.METHOD_POST;
                webRequest.Accept = serenityResponseContentType;
                webRequest.Proxy = null;
                webRequest.Timeout = SerenityConstants.CONNECTION_TIMEOUT_IN_MS;
                webRequest.ServicePoint.MaxIdleTime = SerenityConstants.IDLE_TIMEOUT_IN_MS;
                SetUpAuthHeaders(webRequest);
                webResponse = (HttpWebResponse)(await webRequest.GetResponseAsync());
            }
            catch (WebException ex)
            {
               
                AppLogger.Error("Caught web exception in post resource.", ex);
            }
            catch (Exception ex)
            {
               
                AppLogger.Error("Caught genereic exception in post resource", ex);
            }

            return webResponse;
        }
    }
}
