﻿using Pelco.Phoenix.PluginHostInterfaces;
using SmartElevators.Utils;
using System;
using System.Threading.Tasks;

namespace SmartElevators.Service
{
    class CommunicationManager
    {
        #region Private Fields
        private static CommunicationManager comManagerInstance;
        private string authToken = string.Empty;
        private string baseURI = string.Empty;
        #endregion
        #region Properties

        #region Internal Properties
        internal IOCCHostSerenity hostSerenityInstance;
        #endregion
        public SystemAPI SystemCache;
        private SerenityRestClient serClient;
        public SystemVersionInfo SystemVersionCache;
        public UserAPI UserCache;
        #endregion
        #region Public Methods

        public static CommunicationManager Instance
        {
            get
            {
                if (comManagerInstance == null)
                {
                    comManagerInstance = new CommunicationManager();
                }
                return comManagerInstance;
            }
        }
        public async Task Initialise()
        {
#if DEBUG
            //baseURI = "https://10.1.152.21:443";
            //  baseURI = "https://10.1.151.126:8888";
            //  baseURI = "https://10.1.151.86:8888";
            baseURI = "https://" + System.Configuration.ConfigurationManager.AppSettings.Get("Server");

            //authToken = "ZXlKMWMyVnlibUZ0WlNJNkltRmtiV2x1SWl3aWNHRnpjM2R2Y21RaU9pSmhaRzFwYmlJc0ltUnZiV0ZwYmlJNklreFBRMEZNSWl3aVpYaHdhWEpsY3lJNk1UUXdNalU0TlRJMk9UUTVPQ3dpZEhKMWMzUWlPaUpoWkcxcGJpSjk=";
            //authToken = "admin-admin-LOCAL-228128b9d347";
#else
            if (hostSerenityInstance != null)
            {
                baseURI = hostSerenityInstance.GetBaseURI();
                authToken = hostSerenityInstance.GetAuthToken();
            }
#endif
            serClient = new SerenityRestClient(baseURI, authToken);
            await InvokeBaseAPIs();
        }
        internal async Task<DataSourceCollectionAPI> GetCamerasAsync()
        {
            string camerasLink = string.Empty;
            camerasLink = (SystemCache._links != null) ? SystemCache._links.data_sources : string.Empty;
            if (string.IsNullOrEmpty(camerasLink))
            {
                return null;
            }
            string uri = string.Format("{0}{1}?embed={3}{2}/pelco/rel/device{2}:{3}{4}{4}{5}", baseURI, camerasLink, "\"", "{", "}", "&type=video");
            return await serClient.GetSerenityResource<DataSourceCollectionAPI>(uri, serClient.serenityResponseContentType);
        }
        private async Task InvokeBaseAPIs()
        {
            SystemVersionCache = await GetSystemVersionsAsync();
            serClient.serenityResponseContentType = string.Format("{0}version={1}", SerenityConstants.CONTENT_TYPE_SERENITY_RESPONSE_ANY, SystemVersionCache.current_version);
            SystemCache = await GetSystemAsync();
            //UserCache = await GetUserAsync();
        }

        private async Task<SystemVersionInfo> GetSystemVersionsAsync()
        {
            AppLogger.Trace("Get System Version.");
            string uri = String.Format("{0}/system/versions", baseURI);
            return await serClient.GetSerenityResource<SystemVersionInfo>(uri, SerenityConstants.CONTENT_TYPE_ANY);
        }

        public async Task<SystemAPI> GetSystemAsync()
        {
            AppLogger.Trace("Get System.");
            string uri = String.Format("{0}/system", baseURI);
            return await serClient.GetSerenityResource<SystemAPI>(uri, serClient.serenityResponseContentType);
        }

        public async Task<UserAPI> GetUserAsync()
        {
            AppLogger.Trace("Get User.");
            string uri = String.Format("{0}{1}", baseURI, SystemCache._links.user);
            return await serClient.GetSerenityResource<UserAPI>(uri, serClient.serenityResponseContentType);
        }

        /// <summary>
        /// Gets the data objects associated with current user
        /// </summary>
        /// <returns></returns>
        public async Task<DataObjectsCollection> GetDataobjects()
        {
            string uri = String.Format("{0}{1}", baseURI, UserCache._links.data_objects);
            return await serClient.GetSerenityResource<DataObjectsCollection>(uri, serClient.serenityResponseContentType);
        }

        internal async Task<MonitorCollectionApi> GetMonitorsAsync()
        {
            string uri = String.Format("{0}{1}", baseURI, SystemCache._links.monitors);
            return await serClient.GetSerenityResource<MonitorCollectionApi>(uri, serClient.serenityResponseContentType);
        }

        internal async Task<MonitorApi> GetMonitorAsync(string link)
        {
            string uri = String.Format("{0}{1}", baseURI, link);
            return await serClient.GetSerenityResource<MonitorApi>(uri, serClient.serenityResponseContentType);
        }

        internal async Task<bool> EditMonitorCell(UpdateMonitorCell monitorCell, string editDataLink)
        {
            if (String.IsNullOrWhiteSpace(editDataLink))
            {
                return true;
            }

            string uri = String.Format("{0}{1}", baseURI, editDataLink);

            bool response = await serClient.PatchSerenityResource<UpdateMonitorCell>(uri, monitorCell);
            return response;
        }

        #endregion
    }
}
