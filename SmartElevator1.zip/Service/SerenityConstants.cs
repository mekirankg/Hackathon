﻿namespace SmartElevators.Service
{
    public class SerenityConstants
    {
        public const string CONTENT_TYPE_ANY = "*/*;";
        public const string CONTENT_TYPE_SERENITY_RESPONSE_ANY = "application/vnd.pelco.resource+json;";
        public const string COOKIE_NAME_AUTHTOKEN = "auth_token";

        /// <summary>
        /// Represesents xSerenityUser constant variable.
        /// </summary>
        public const string X_SERENITY_USER = "X-Serenity-User";

        /// <summary>
        /// Represesents xSerenityPassword constant variable.
        /// </summary>
        public const string X_SERENITY_PASSWORD = "X-Serenity-Password";

        public const string METHOD_GET = "GET";
        public const string METHOD_POST = "POST";
        public const string METHOD_DELETE = "DELETE";
        public const string METHOD_PATCH = "PATCH";
        public const string METHOD_PUT = "PUT";
        public const string HEADER_ACCEPT = "Accept";
        public const string HEADER_COOKIE = "Cookie";
        public const string HEADER_CONTENT_TYPE = "Content-Type";
        public const string CONTENT_TYPE_SERENITY_PATCH = "application/vnd.pelco.patch+json";
        public const string USER_AGENT = "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36";
        public const int CONNECTION_TIMEOUT_IN_MS = 15000;
        public const int IDLE_TIMEOUT_IN_MS = 15000;
    }
}
