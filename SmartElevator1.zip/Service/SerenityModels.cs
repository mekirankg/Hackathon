﻿using System;
using System.Collections.Generic;

namespace SmartElevators.Service
{
    public class SerenityAPIBaseModel
    {
        public string id { get; set; }

        public string httpStatusCode { get; set; }
    }

    public class APICollectionModelBase
    { }

    public class APILinkBase
    {
        public string self { get; set; }
        public string edit { get; set; }
    }

    public class APICollectionLink
    {
        public string next { get; set; }
        public string prev { get; set; }
    }

    public class APICollectionHeader
    {
        public bool partial { get; set; }
        public int start_index { get; set; }
        public int total_items { get; set; }
        public APICollectionLink _links { get; set; }
    }

    public class SystemVersionInfo : SerenityAPIBaseModel
    {
        public string current_version { get; set; }
        public List<string> supported_versions { get; set; }
        public string _type { get; set; }
    }

    public class SystemAPILink : APILinkBase
    {
        public string bookmarks { get; set; }
        public string clips { get; set; }
        public string data_objects { get; set; }
        public string data_sessions { get; set; }
        public string data_sources { get; set; }
        public string data_storages { get; set; }
        public string devices { get; set; }
        public string drawings { get; set; }
        public string event_wss { get; set; }
        public string events { get; set; }
        public string event_subs { get; set; }

        public string exports { get; set; }
        public string export_players { get; set; }
        public string license { get; set; }
        public string locks { get; set; }
        public string members { get; set; }
        public string monitors { get; set; }
        public string monitor_walls { get; set; }
        public string notifications { get; set; }
        public string quickreport { get; set; }
        public string roles { get; set; }
        public string situations { get; set; }
        public string tags { get; set; }
        public string user { get; set; }
        public string users { get; set; }
    }

    public class SystemAPI : SerenityAPIBaseModel
    {
        public string name { get; set; }
        public SystemAPILink _links { get; set; }
    }

    public class UserAPILink : APILinkBase
    {
        public string account { get; set; }
        public string auth { get; set; }
        public string data_objects { get; set; }
        public string delete { get; set; }
        public string new_password { get; set; }
        public string roles { get; set; }
        public string tags { get; set; }
    }

    public class UserAPI : SerenityAPIBaseModel
    {
        public string domain { get; set; }
        public string name { get; set; }
        public string password_expiration { get; set; }
        public UserAPILink _links { get; set; }
    }

    public class DrawingAPILink : APILinkBase
    {
        public string delete { get; set; }
        public string delete_image { get; set; }
        public string heob { get; set; }
        public string image { get; set; }
        public string @lock { get; set; }
        public string markers { get; set; }
        public string setheob { get; set; }
        public string setimage { get; set; }
        public string setlock { get; set; }
    }

    public class DrawingAPI : SerenityAPIBaseModel
    {
        public string name { get; set; }
        public DateTime _last_modified { get; set; }
        public DrawingAPILink _links { get; set; }
    }

    public class DrawingCollectionHeaderLink
    {
        public string edit { get; set; }
        public string add_drawing { get; set; }
    }

    public class DrawingCollectionAPI : APICollectionModelBase
    {
        public APICollectionHeader collection_header { get; set; }
        public List<DrawingAPI> drawings { get; set; }
        public List<string> index { get; set; }
        public DrawingCollectionHeaderLink _links { get; set; }
    }

    public class MonitorApi : SerenityAPIBaseModel
    {
        public string name { get; set; }
        public List<MonitorCell> cells { get; set; }
        public string layout { get; set; }
        public int number { get; set; }

        public MonitorAPILink _links { get; set; }
    }

    public class MonitorCell
    {
        public string data_source_id { get; set; }
        public int index { get; set; }
        public float speed { get; set; }
        public string time { get; set; }
        public string time_anchor { get; set; }

        public MonitorCellLink _links { get; set; }

    }

    public class MonitorCellLink : APILinkBase
    {

    }

    public class MonitorAPILink : APILinkBase
    {
        public string delete { get; set; }
        //  public string contents { get; set; }
        public string device { get; set; }
        //    public string monitorlock { get; set; }
        public string monitor_walls { get; set; }
        //   public string snapshot { get; set; }       
    }

    public class MonitorCollectionApi : APICollectionModelBase
    {
        public APICollectionHeader collection_header { get; set; }
        public List<MonitorApi> monitors { get; set; }

        public MonitorCollectionHeaderLink _links { get; set; }
    }

    public class MonitorCollectionHeaderLink
    {
        public string add_monitor { get; set; }
    }

    public class DataObjectLink : APILinkBase
    {
        public string delete { get; set; }
        public string user { get; set; }
    }

    public class DataObject : SerenityAPIBaseModel
    {
        public string client_type { get; set; }
        public string data { get; set; }
        public string owner { get; set; }
        public DataObjectLink _links { get; set; }
    }
    public class DataObjectCollectionHeaderLink
    {
        public string add_private_data { get; set; }
        public string add_public_data { get; set; }
    }

    public class DataObjectsCollection : APICollectionModelBase
    {
        public APICollectionHeader collection_header { get; set; }
        public List<DataObject> data_objects { get; set; }

        public DataObjectCollectionHeaderLink _links { get; set; }

    }


    public class ResourceRef
    {
        public string id { get; set; }
        public string type { get; set; }
    }

    public class MarkerAPILink : APILinkBase
    {
        public string delete { get; set; }
        public string drawing { get; set; }
        public string resource { get; set; }
    }

    public class MarkerAPI : SerenityAPIBaseModel
    {
        public double direction { get; set; }
        public string name { get; set; }
        public ResourceRef resource_ref { get; set; }
        public double x { get; set; }
        public double y { get; set; }
        public MarkerAPILink _links { get; set; }
    }

    public class MarkerCollectionHeaderLink
    {
        public string add_marker { get; set; }
        public string na_resources { get; set; }
    }

    public class MarkerCollectionAPI : APICollectionModelBase
    {
        public APICollectionHeader collection_header { get; set; }
        public List<MarkerAPI> markers { get; set; }
        public MarkerCollectionHeaderLink _links { get; set; }
    }

    public class PTZControllerAPILink : APILinkBase
    {
        public string patterns { get; set; }
        public string presets { get; set; }
        public string ptzlock { get; set; }
        public string view_object { get; set; }
    }

    public class PTZControllerAPI
    {
        public int focus { get; set; }
        public int iris { get; set; }
        public bool locked { get; set; }
        public int lock_expire_time { get; set; }
        public int vfocus { get; set; }
        public int viris { get; set; }
        public int vx { get; set; }
        public int vy { get; set; }
        public int vz { get; set; }
        public int x { get; set; }
        public int y { get; set; }
        public int z { get; set; }
        public PTZControllerAPILink _links { get; set; }
    }

    public class DeviceAPILink : APILinkBase
    {
        public string configuration { get; set; }
        public string data_sources { get; set; }
        public string data_storages { get; set; }
        public string delete { get; set; }
        public string diagnostic { get; set; }
        public string license { get; set; }
        public string monitors { get; set; }
        public string monitor_walls { get; set; }
        public string reboot { get; set; }
        public string reset { get; set; }
    }

    public class DeviceAPI : SerenityAPIBaseModel
    {
        public string base_version { get; set; }
        public string ddf_location { get; set; }
        public bool commissioned { get; set; }
        public string ip { get; set; }
        public bool license_required { get; set; }
        public string model { get; set; }
        public string name { get; set; }
        public string onvif_entry { get; set; }
        public string serial { get; set; }
        public string state { get; set; }
        public string type { get; set; }
        public string version { get; set; }
        public string vip { get; set; }
        public DeviceAPILink _links { get; set; }
    }

    public class EmbeddedDataSourceDetail
    {
        public DeviceAPI device { get; set; }
    }

    public class DataInterfaceAPI
    {
        public string endpoint { get; set; }
        public bool multicast { get; set; }
        public string protocol { get; set; }
    }

    public class DataSourceAPILink : APILinkBase
    {
        public string bookmarks { get; set; }
        public string clips { get; set; }
        public string data_sessions { get; set; }
        public string data_storages { get; set; }
        public string device { get; set; }
        public string member { get; set; }
        public string ptz_controller { get; set; }
        public string snapshot { get; set; }
    }

    public class DataSourceAPI : SerenityAPIBaseModel
    {
        public bool capturing { get; set; }
        public List<DataInterfaceAPI> data_interfaces { get; set; }
        public string ip { get; set; }
        public bool live { get; set; }
        public string name { get; set; }
        public int number { get; set; }
        public bool recorded { get; set; }
        public bool recording { get; set; }
        public string state { get; set; }
        public string type { get; set; }
        public DataSourceAPILink _links { get; set; }
        public EmbeddedDataSourceDetail _embedded { get; set; }
    }

    public class DataSourceCollectionAPI : APICollectionModelBase
    {
        public APICollectionHeader collection_header { get; set; }
        public List<DataSourceAPI> data_sources { get; set; }
    }

    public class ResourceLockAPI : SerenityAPIBaseModel
    {
        public ResourceLockAPILink _links { get; set; }
        public string owner { get; set; }

        public class ResourceLockAPILink
        {
            public string delete { get; set; }
        }
    }

    public class Resource : SerenityAPIBaseModel
    {
        public string ip { get; set; }
        public string name { get; set; }
        public int number { get; set; }
        public string state { get; set; }
        public string type { get; set; }
        public bool live { get; set; }
        public bool recorded { get; set; }
        public string _type { get; set; }
        public string model { get; set; }
        public string serial { get; set; }
        public string version { get; set; }
        public string ddf_location { get; set; }
        public bool? enabled { get; set; }
    }

    public class ResourceDetail
    {
        public List<Resource> resources { get; set; }
    }

    public class EmbeddedTagDetail
    {
        public ResourceDetail resources { get; set; }
    }

    public class TagAPI : SerenityAPIBaseModel
    {
        public string name { get; set; }
        public string owner { get; set; }
        public EmbeddedTagDetail _embedded { get; set; }
    }

    public class TagsCollectionAPI : APICollectionModelBase
    {
        public List<TagAPI> tags { get; set; }
    }

    public class UpdateMarker
    {
        public double direction { get; set; }
        public double x { get; set; }
        public double y { get; set; }
    }

    public class UpdateDataObject
    {
        public string data { get; set; }
    }

    public class UpdateMonitorCell
    {
        public string data_source_id { get; set; }
        public float speed { get; set; }
        public string time { get; set; }
    }

    public class P_Links
    { }

    public class P_CollectionHeader
    {
        public bool partial { get; set; }
        public int start_index { get; set; }
        public int total_items { get; set; }
        public P_Links _links { get; set; }
        public string _type { get; set; }
    }

    public class P_Links2
    {
        public string self { get; set; }
        public string edit { get; set; }
        public string delete { get; set; }
        public string link { get; set; }
        public string unlink { get; set; }
        public string merge { get; set; }
        public string resources { get; set; }
    }

    public class P_Resourcerefs
    {
        public string _type { get; set; }
        public List<ResourceRef> value { get; set; }
    }

    public class P_Embedded
    {
        public P_Resourcerefs resourcerefs { get; set; }
    }

    public class P_Tag
    {
        public string _type { get; set; }
        public string id { get; set; }
        public string name { get; set; }
        public P_Links2 _links { get; set; }
        public P_Embedded _embedded { get; set; }
    }

    public class P_Links3
    {
        public string add_tag { get; set; }
    }

    public class P_Camera_Tag
    {
        public P_CollectionHeader collection_header { get; set; }
        public List<P_Tag> tags { get; set; }
        public P_Links3 _links { get; set; }
        public string _type { get; set; }
    }

    public class Event_Subscriptions
    {
        public Event_Subscription_Collection_Header collection_header { get; set; }

        public List<Event_Subscription> subscriptions { get; set; }

        public Event_Subscriptions_Links _links { get; set; }
    }

    public class Event_Subscription
    {
        public string endpoint { get; set; }
        public int expires { get; set; }
        public string id { get; set; }
        public List<String> situation_types { get; set; }

        public Event_Subscription_Links _links { get; set; }
    }

    public class Event_Subscription_Collection_Header
    {
        public bool partial { get; set; }
        public int start_index { get; set; }
        public int total_items { get; set; }

        public string _type { get; set; }
    }

    public class Event_Subscription_Links
    {
        public string delete { get; set; }
        public string refresh { get; set; }
    }

    public class Event_Subscriptions_Links
    {
        public string add_subscription { get; set; }
    }

    /// <summary>
    /// For get the Tag details of a specific tag id
    /// </summary>
    public class P_TagDetails : SerenityAPIBaseModel
    {
        public string _type { get; set; }
        public string name { get; set; }
        public P_Links2 _links { get; set; }
    }

}
