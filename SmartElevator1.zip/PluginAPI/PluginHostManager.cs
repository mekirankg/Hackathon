﻿using Pelco.Phoenix.PluginHostInterfaces;
using SmartElevators.ViewModel;
using System;
using System.Collections.Generic;
using SmartElevators.Utils;
using SmartElevators.PluginAPI;

namespace SmartElevators.PluginAPI
{
    public class PluginHostManager
    {
        private IHost _host = null;
        
        private static PluginHostManager pluginHostManagerInstance;
     
        public static PluginHostManager PluginHostManagerInstance
        {
            get
            {

                return pluginHostManagerInstance;
            }
        }

       

        public IHost TheHost
        {
            get { return _host; }
            set
            {
                pluginHostManagerInstance = this;

                if (value == null)
                {
                    
                    return;
                }
                else
                {                   
                    if (_host != value)
                    {
                        
                    }                    
                }
            }
        }
        public Plugin ThePlugIn { get; set; }
        public MainViewModel TheMainViewModel { get; set; }
        
        #region IHost
        public int HostProcessId
        {
            
            get {
                AppLogger.Info("HostProcessId called");
                throw new NotImplementedException(); }
        }

        public void ReportFatalError(string userMessage, string fullExceptionText)
        {
            AppLogger.Info("ReportFatalError called");
            throw new NotImplementedException();
        }

        public void RequestClose()
        {
            AppLogger.Info("RequestClose called");
            throw new NotImplementedException();
        }

        public void RequestFullScreen()
        {
            AppLogger.Info("RequestFullScreen called");
            throw new NotImplementedException();
        }

        public void ReturnFromFullScreen()
        {
            AppLogger.Info("ReturnFromFullScreen called");
            throw new NotImplementedException();
        } 

        public object GetService(Type serviceType)
        {
            AppLogger.Info("GetService called");
            throw new NotImplementedException();
        }
        #endregion

        #region IOCCHost1 (IOCCHostGeneral)
        

        public void StoreCredentials(string credentials)
        {
            AppLogger.Info("StoreCredentials called");
            throw new NotImplementedException();
        }

        public void InitiateStreams(List<string> cameraList)
        {
            AppLogger.Info("InitiateStreams called");
            throw new NotImplementedException();
        }
        #endregion

        #region IOCCHostSerenity
        public string GetAuthToken()
        {
            AppLogger.Info("GetAuthToken called");
            throw new NotImplementedException();
        }

        public string GetBaseURI()
        {
            AppLogger.Info("GetBaseURI called");
            throw new NotImplementedException();
        } 
        #endregion

        #region IOCCHostJoystick
        public void EscJoystick()
        {
            AppLogger.Info("EscJoystick called");
            throw new NotImplementedException();
        }

        public void RegisterForJoystickNotifications(bool send)
        {
            AppLogger.Info("RegisterForJoystickNotifications called");
            throw new NotImplementedException();
        }

        public void SetJoystickLimits(int xMin, int xMax, int yMin, int yMax, int zMin, int zMax, int uMin, int uMax)
        {
            AppLogger.Info("SetJoystickLimits called");
            throw new NotImplementedException();
        } 
        #endregion

        #region IOCCHostRegisterForDragDrop
        public void RegisterForDragDrop(bool send)
        {
            AppLogger.Info("RegisterForDragDrop called");
            throw new NotImplementedException();
        } 
        #endregion
    }
}
