﻿/**********************************************************************************
* File Name   :   Plugin.cs
* Description :   This class implements the plug-in interfaces, which enables 
*                 the application to be easily plug and play with Ops-Center. 
*
* Copyright (c) 2015 Pelco Products, Inc.
* --------------------------------------------------------------------------------
* Date             Author              Comment
* --------------------------------------------------------------------------------
* 23-Nov-2015      QuEST Team          Initial version created
**********************************************************************************/

#region Namespaces

using SmartElevators.Resources.Lang;
using SmartElevators.Utils;
using SmartElevators.ViewModel;
using SmartElevators.Views;
using Pelco.Phoenix.PluginHostInterfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using System.Windows;
using System.Xml.Linq;
#endregion

namespace SmartElevators.PluginAPI
{
    public class Plugin : PluginBase, IOCCPluginOverlay, IOCCPlugin1
    {
        #region Private Members
        private MainUserControl pluginUIControl;
        private PluginState pluginStateInfo;
        private PluginHostManager hostManager;     
      
        
        private IHost host;

        private static Dictionary<string, string> toolPreferenceMapping =
            new Dictionary<string, string>();

        private static Plugin pluginInstance;
        #endregion

        #region Properties
        public static Plugin PluginInstance
        {
            get
            {
                return pluginInstance;
            }
        }

        public IOCCHostSetVideoPosition _IOCCHostSetVideoPosition { get; set; }

        public IOCCHostOverlay _OCCHostOverlay
        { get; set; }

       

        #endregion

        #region Constructors
        public Plugin()
        {
            hostManager = new PluginHostManager();
            hostManager.ThePlugIn = this;
            

            LoadPluginParamsFromXML();
            pluginInstance = this;
        }

        public Plugin(IHost host)
        {
            try
            {

               
                AppDomain.CurrentDomain.ProcessExit += CurrentDomain_ProcessExit;
               
                if (host != null)
                {
                    this.host = host;
                    AppLogger.Info("Plugin::Plugin invoked - Host reference passed in is OK");
                    pluginInstance = this;
                    _OCCHostOverlay = host.GetService<IOCCHostOverlay>();
                    _OCCHostOverlay.RegisterForVideoCellNotifications(true);
                    _OCCHostOverlay.SetOverlayAnchor(AnchorTypes.left, 30, 200, 300);
                    _IOCCHostSetVideoPosition = host.GetService<IOCCHostSetVideoPosition>();
                }
                else
                {
                    AppLogger.Info("Plugin::Plugin invoked - Host reference passed in is NULL");
                }
                LoadPluginParamsFromXML();
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Plugin invoked - Host reference passed in is NULL", ex);
            }
        }
        #endregion

        #region PluginBase
        public override FrameworkElement CreateControl()
        {
            AppLogger.Info("Plugin::CreateControl Called");

            try
            {
               
                if (host != null)
                {
                    pluginInitialRegistrations();                   
                }
               
                if (pluginUIControl == null)
                {
                    SetGlobalResources();
                    pluginUIControl = new MainUserControl();
                }
                
                    pluginUIControl.InitializeSmartElevator(pluginStateInfo);
                 //   MainViewModel.Instance.TheHostApp = this.host;
                   
               
            }
            catch (Exception ex)
            {
                AppLogger.Error("CreateControl Error-", ex);
            }
            return pluginUIControl;
        }

        public override string Description
        {
            get
            {
                AppLogger.Info("Plugin::Description Called");
                               return toolPreferenceMapping[PluginConstants.PLUGIN_DESCRIPTION];
            }
        }

        public override string GetPluginKey()
        {
            AppLogger.Info("Plugin::GetPluginKey Called");
                       return toolPreferenceMapping[PluginConstants.PLUGIN_KEY]; ;//PluginConstants.PLUGIN_KEY;
        }
        public override bool IsOverlay
        {
            get
            {
                AppLogger.Info("Plugin::IsOverlay Called");
                bool retVal = true;
                             return retVal;
            }
        }

        public override string Name
        {
            get
            {
                AppLogger.Info("Plugin::Name Called");
                               return toolPreferenceMapping[PluginConstants.PLUGIN_NAME]; ;//PluginConstants.PLUGIN_NAME;
            }
        }

        public override string PluginID
        {
            get
            {
                              return toolPreferenceMapping[PluginConstants.PLUGIN_ID]; ;//PluginConstants.PLUGIN_ID;
            }
        }

        public override void Shutdown()
        {
            try
            {
                AppLogger.Info("Plugin::Shutdown Called");
                IOCCHost1 hostGeneral = host.GetService<IOCCHost1>();
                            //Persistence.Instance.StoreTestStatus(InterfacesNames.INTERFACE_IHOST, APINames.REQUEST_CLOSE, APITestStatus.IN_PROGRESS, null, null);
                //Persistence.Instance.SaveInitialStatusToXML();

                host.RequestClose();
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Shutdown Error", ex);
            }
        }

        public override string Version
        {
            get
            {
                AppLogger.Info("Plugin::Version Called");
                             return toolPreferenceMapping[PluginConstants.PLUGIN_VERSION]; ;//PluginConstants.PLUGIN_VERSION;
            }
        }
        #endregion

        #region IOCCPlugin1
        public string GetPluginState()
        {
            string pluginState = string.Empty;
            try
            {
                pluginStateInfo = new PluginState();

              
                //To Do, populate the data members
                JavaScriptSerializer js = new JavaScriptSerializer();
                pluginState = js.Serialize(pluginStateInfo);
                //overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.GET_PLUGIN_STATE, APITestStatus.PASSED);
            }
            catch (Exception ex)
            {
                AppLogger.Error("GetPluginState", ex);
            }
            return pluginState;
        }

        public void Login(string credentials)
        {
            try
            {
                           }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Login Error", ex);
            }
        }

        public void Logout()
        {
            try
            {
                AppLogger.Info("Plugin::Logout Called");
                //overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.LOGOUT, APITestStatus.PASSED);
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Logout Error", ex);
            }
        }

        public bool RequiresCredentials
        {
            get
            {
                AppLogger.Info("Plugin::RequiresCredentials Called");
                bool returnVal = true;
               
                //overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.REQUIRES_CREDENTIALS,
                //    APITestStatus.PASSED, null, outParam);
                return returnVal;
            }
        }

        public void SetPluginState(string pluginState)
        {
            if (string.IsNullOrEmpty(pluginState))
            {
                AppLogger.Error("Plugin::SetPluginState - pluginState is Empty*****************");
                return;
            }
            try
            {

                AppLogger.Info("Plugin::SetPluginState Called");
                           }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::SetPluginState Error", ex);
            }
        }
        #endregion

        #region Helper Methods
        private void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            AppLogger.Info("Plugin::CurrentDomain_ProcessExit Called");
            try
            {
              
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::CurrentDomain_ProcessExit- Error", ex);
            }
        }


        private void pluginInitialRegistrations()
        {
            AppLogger.Info("Plugin::pluginInitialRegistrations Called");
            hostManager = new PluginHostManager();
            hostManager.ThePlugIn = this;
            hostManager.TheHost = this.host;
        }

        private void SetGlobalResources()
        {
            AppLogger.Info("Plugin::SetGlobalResources Called");
            // Set the static values that would be instantiated in App.xaml
            // Create ViewModelLocator
            //App.Current.Resources.Add("Locator", new ViewModelLocator());
            // Declare global assets
            AddResourceDictionaries
                (
                @"Resources/Helpers/Converters.xaml",
                @"Resources/Styles/Styles.xaml",
                @"Resources/Styles/Colors.xaml",
                @"Resources/Styles/Images.xaml",
                @"Resources/Styles/PluginStyles.xaml",
                @"Resources/Styles/HoverImageButtonTheme.xaml",
                @"Resources/Styles/GlobalScrollBarStyle.xaml"
                );
        }

        private void AddResourceDictionaries(params string[] uris)
        {
            foreach (string uri in uris)
            {
                ResourceDictionary resourceDict = new ResourceDictionary();
                resourceDict.Source = new Uri(uri, UriKind.Relative);
                App.Current.Resources.MergedDictionaries.Add(resourceDict);
            }
        }

        /// <summary>
        ///  Plugin params, such as Name, Description, Key and ID reading from an XML file 
        /// </summary>
        public void LoadPluginParamsFromXML()
        {
            try
            {
                AppLogger.Info("Plugin::LoadPluginParamsFromXML Called");
                //get the full location of the assembly with DaoTests in it
                string fullPath = System.Reflection.Assembly.GetAssembly(typeof(Plugin)).Location;
                AppLogger.Info("fullPath" + fullPath);
                //get the folder that's in
                string theDirectory = Path.GetDirectoryName(fullPath);
                AppLogger.Info("Directory" + theDirectory);
                AppLogger.Info("_______ ____Xml Reading__ ______");
                string PluginParamsFileUrl = Path.Combine(theDirectory, "OverlayPluginParams.xml");
                AppLogger.Info("The path for PluginParamsFileUrl is " + PluginParamsFileUrl);

                if (File.Exists(PluginParamsFileUrl))
                {
                    XDocument toolPreferenceXml = XDocument.Load(PluginParamsFileUrl);
                    toolPreferenceMapping = toolPreferenceXml.Descendants(
                        PluginConstants.PluginXmlTagIdentifier).ToDictionary(
                            x => x.Attribute(PluginConstants.PluginNameAttribute).Value,
                            x => x.Attribute(PluginConstants.PluginValueAttribute).Value);
                }
                else
                {
                    AppLogger.Info("The OverlayPluginParams.xml file not exist");
                }
            }
            catch (Exception ex)
            {
                AppLogger.Error("LoadPluginParamsFromXML", ex);
            }
        }

        #endregion

        #region IOCCPluginOverlay Implementations

        public void OnVideoPlayPause(string dataSourceId, string number, bool live, bool playing, DateTime utcTime)
        {
            pluginUIControl.Dispatcher.BeginInvoke(new Action(() =>
            {
               

            }));
        }
        public void OnVideoTimer(DateTime streamTime)
        {
            pluginUIControl.Dispatcher.BeginInvoke(new Action(() =>
            {
                
            }));
        }

        public void OnVideoRemoved()
        {
            pluginUIControl.Dispatcher.BeginInvoke(new Action(() =>
            {
                
            }));
        }

        #endregion

        #region IOCCPlugin1 Implementations

        public void OnThumbnailPreferenceNotification(bool show)
        {
            //throw new NotImplementedException();
        }

        public void OnCameraOnScreeen(string cameraId, bool onScreen)
        {
            //throw new NotImplementedException();
        }


        #endregion
    }
}

