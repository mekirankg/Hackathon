﻿/**********************************************************************************
* File Name   :   Plugin.cs
* Description :   This class implements the plug-in interfaces, which enables 
*                 the application to be easily plug and play with Ops-Center. 
*
* Copyright (c) 2015 Pelco Products, Inc.
* --------------------------------------------------------------------------------
* Date             Author              Comment
* --------------------------------------------------------------------------------
* 23-Nov-2015      QuEST Team          Initial version created
**********************************************************************************/

#region Namespaces
using Pelco.Phoenix.OverlayAPITester.Models;
using Pelco.Phoenix.OverlayAPITester.Resources.Lang;
using Pelco.Phoenix.OverlayAPITester.Utils;
using Pelco.Phoenix.OverlayAPITester.ViewModel;
using Pelco.Phoenix.OverlayAPITester.Views;
using Pelco.Phoenix.PluginHostInterfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using System.Windows;
using System.Xml.Linq;
#endregion

namespace Pelco.Phoenix.OverlayAPITester.PluginAPI
{
    public class Plugin : PluginBase, IOCCPluginOverlay, IOCCPlugin1, IOCCPluginReserved
    {
        #region Private Members
        private MainUserControl pluginUIControl;
        private PluginState pluginStateInfo;
        private PluginHostManager hostManager;
        private OverlayTester overlayTester;
        private OverlayAnchor overlayAnchor;
        private VideoAPI videoAPI;
        private IHost host;

        private static Dictionary<string, string> toolPreferenceMapping =
            new Dictionary<string, string>();

        private static Plugin pluginInstance;
        #endregion

        #region Properties
        public static Plugin PluginInstance
        {
            get
            {
                return pluginInstance;
            }
        }

        public IOCCHostSetVideoPosition _IOCCHostSetVideoPosition { get; set; }

        public IOCCHostOverlay _OCCHostOverlay
        { get; set; }

        public APICallFlags CallStatus
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        public Plugin()
        {
            hostManager = new PluginHostManager();
            hostManager.ThePlugIn = this;
            overlayTester = OverlayTester.GetInstance;
            videoAPI = VideoAPI.Instance;

            LoadPluginParamsFromXML();
            pluginInstance = this;
        }

        public Plugin(IHost host)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();
                overlayAnchor = OverlayAnchor.Instance;
                videoAPI = VideoAPI.Instance;
                AppDomain.CurrentDomain.ProcessExit += CurrentDomain_ProcessExit;
                overlayTester = OverlayTester.GetInstance;
                if (host != null)
                {
                    this.host = host;
                    AppLogger.Info("Plugin::Plugin invoked - Host reference passed in is OK");
                    pluginInstance = this;
                    _OCCHostOverlay = host.GetService<IOCCHostOverlay>();
                    _OCCHostOverlay.RegisterForVideoCellNotifications(true);
                    _IOCCHostSetVideoPosition = host.GetService<IOCCHostSetVideoPosition>();
                }
                else
                {
                    AppLogger.Error("Plugin::Plugin invoked - Host reference passed in is NULL");
                }
                LoadPluginParamsFromXML();
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Plugin invoked - Host reference passed in is NULL");
            }
        }
        #endregion

        #region PluginBase
        public override FrameworkElement CreateControl()
        {
            AppLogger.Info("Plugin::CreateControl Called");
            //System.Diagnostics.Debugger.Launch();
            try
            {
                overlayTester.RestoreTestStateAsync();
                if (host != null)
                {
                    pluginInitialRegistrations();
                }
                if (pluginUIControl == null)
                {
                    SetGlobalResources();
                    pluginUIControl = new MainUserControl();
                }

                if (overlayTester.PluginIntefaceCollection == null)
                {
                    pluginUIControl.ShowCustomMessage("OverlayAPIInterfacesDetails.XML not found or corrupted.\nPlease refer logs for details", PluginStrings.Ok, false, PluginStrings.Error);
                    pluginUIControl = null;
                }
                else
                {
                    pluginUIControl.InitializePluginAPITester(pluginStateInfo);
                    MainViewModel.Instance.TheHostApp = this.host;
                    OutputParameter outparam = new OutputParameter()
                    {
                        ParameterType = ParameterTypeEnum.OBJECT,
                        Value = (pluginUIControl != null ? Constants.REPORT_OBJECT_NOT_NULL : Constants.REPORT_OBJECT_NULL)
                    };
                    overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.CREATE_CONTROL, APITestStatus.PASSED,
                        null, outparam);
                }
            }
            catch (Exception ex)
            {
                AppLogger.Error("CreateControl Error-", ex);
            }
            return pluginUIControl;
        }

        public override string Description
        {
            get
            {
                AppLogger.Error("Plugin::Description Called");
                OutputParameter outparam = new OutputParameter()
                {
                    ParameterType = ParameterTypeEnum.STRING,
                    Value = toolPreferenceMapping[PluginConstants.PLUGIN_DESCRIPTION]
                };
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.DESCRIPTION, APITestStatus.PASSED, null, outparam);
                return toolPreferenceMapping[PluginConstants.PLUGIN_DESCRIPTION];
            }
        }

        public override string GetPluginKey()
        {
            AppLogger.Info("Plugin::GetPluginKey Called");
            OutputParameter outparam = new OutputParameter()
            {
                ParameterType = ParameterTypeEnum.STRING,
                Value = toolPreferenceMapping[PluginConstants.PLUGIN_KEY]
            };
            overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.GET_PLUGIN_KEY, APITestStatus.PASSED, null, outparam);
            AppLogger.Info(toolPreferenceMapping[PluginConstants.PLUGIN_KEY]);
            return toolPreferenceMapping[PluginConstants.PLUGIN_KEY] ;//PluginConstants.PLUGIN_KEY;
        }

        public override bool IsOverlay
        {
            get
            {
                AppLogger.Error("Plugin::IsOverlay Called");
                bool retVal = true;
                OutputParameter outparam = new OutputParameter()
                {
                    ParameterType = ParameterTypeEnum.BOOLEAN,
                    Value = retVal.ToString()
                };
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.IS_OVERLAY, APITestStatus.PASSED, null, outparam);
                return retVal;
            }
        }

        public override string Name
        {
            get
            {
                AppLogger.Error("Plugin::Name Called");
                OutputParameter outparam = new OutputParameter()
                {
                    ParameterType = ParameterTypeEnum.STRING,
                    Value = toolPreferenceMapping[PluginConstants.PLUGIN_NAME]
                };
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.NAME, APITestStatus.PASSED, null, outparam);
                AppLogger.Info(toolPreferenceMapping[PluginConstants.PLUGIN_NAME]);
                return toolPreferenceMapping[PluginConstants.PLUGIN_NAME]; //PluginConstants.PLUGIN_NAME;
            }
        }

        public override string PluginID
        {
            get
            {
                AppLogger.Error("Plugin::PluginID Called");
                OutputParameter outparam = new OutputParameter()
                {
                    ParameterType = ParameterTypeEnum.STRING,
                    Value = toolPreferenceMapping[PluginConstants.PLUGIN_ID]
                };
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.PLUGIN_ID, APITestStatus.PASSED, null, outparam);
                AppLogger.Info(toolPreferenceMapping[PluginConstants.PLUGIN_ID]);
                return toolPreferenceMapping[PluginConstants.PLUGIN_ID]; ;//PluginConstants.PLUGIN_ID;
            }
        }

        public override void Shutdown()
        {
            try
            {
                AppLogger.Error("Plugin::Shutdown Called");
                IOCCHost1 hostGeneral = host.GetService<IOCCHost1>();
                hostGeneral.StoreCredentials(overlayTester.GetStoredCredentials());
                AppLogger.Info("StoreCredentials called" + overlayTester.GetStoredCredentials());
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.SHUTDOWN, APITestStatus.PASSED);
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IHOST, APINames.REQUEST_CLOSE, APITestStatus.IN_PROGRESS);
                host.RequestClose();
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Shutdown Error", ex);
            }
        }

        public override string Version
        {
            get
            {
                AppLogger.Error("Plugin::Version Called");
                OutputParameter outparam = new OutputParameter()
                {
                    ParameterType = ParameterTypeEnum.STRING,
                    Value = toolPreferenceMapping[PluginConstants.PLUGIN_VERSION]
                };
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IPLUGIN, APINames.VERSION, APITestStatus.PASSED, null, outparam);
                AppLogger.Info(toolPreferenceMapping[PluginConstants.PLUGIN_VERSION]);
                return toolPreferenceMapping[PluginConstants.PLUGIN_VERSION]; ;//PluginConstants.PLUGIN_VERSION;
            }
        }
        #endregion

        #region IOCCPlugin1
        public string GetPluginState()
        {
            string pluginState = string.Empty;
            try
            {
                pluginStateInfo = new PluginState();

                //videoAPI.GetPluginState(pluginStateInfo);
                //overlayAnchor.GetPluginState(pluginStateInfo);
                //RequestAnnotate.Instance.GetPluginState(pluginStateInfo);//ToDo:: Uncomment
                //To Do, populate the data members
                JavaScriptSerializer js = new JavaScriptSerializer();
                pluginState = js.Serialize(pluginStateInfo);
                //overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.GET_PLUGIN_STATE, APITestStatus.PASSED);
            }
            catch (Exception ex)
            {
                AppLogger.Error("GetPluginState", ex);
            }
            return pluginState;
        }

        public void Login(string credentials)
        {
            try
            {
                AppLogger.Info("Plugin::Login Called");
                List<InputParameter> inputParams = new List<InputParameter>();
                inputParams.Add(new InputParameter() { ParameterName = "credentials", ParameterType = ParameterTypeEnum.STRING, Value = credentials });
                APITestStatus testStatus = overlayTester.TestAPI(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.LOGIN, credentials);
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCHOST1, APINames.STORE_CREDENTIALS, testStatus, inputParams);
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.LOGIN, testStatus, inputParams);
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Login Error", ex);
            }
        }

        public void Logout()
        {
            try
            {
                AppLogger.Info("Plugin::Logout Called");
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.LOGOUT, APITestStatus.PASSED);
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::Logout Error", ex);
            }
        }

        public bool RequiresCredentials
        {
            get
            {
                AppLogger.Info("Plugin::RequiresCredentials Called");
                bool returnVal = false;
                OutputParameter outParam = new OutputParameter()
                { ParameterType = ParameterTypeEnum.BOOLEAN, Value = returnVal.ToString() };

                //overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.REQUIRES_CREDENTIALS,
                //    APITestStatus.PASSED, null, outParam);
                return returnVal;
            }
        }

        public void SetPluginState(string pluginState)
        {
            try
            {
                AppLogger.Info("Plugin::SetPluginState Called");
                List<InputParameter> inputParams = new List<InputParameter>();
                inputParams.Add(new InputParameter() { ParameterName = "pluginState", ParameterType = ParameterTypeEnum.STRING, Value = pluginState.ToString() });
                APITestStatus testStatus = overlayTester.TestAPI(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.SET_PLUGIN_STATE, pluginState);
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN1, APINames.SET_PLUGIN_STATE, testStatus, inputParams);
                pluginStateInfo = new JavaScriptSerializer().Deserialize<PluginState>(pluginState);

                //overlayAnchor.SetPluginState(pluginStateInfo);
                //videoAPI.SetPluginState(pluginStateInfo);
                //RequestAnnotate.Instance.SetPluginState(pluginStateInfo);//ToDo:: Uncomment

            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::SetPluginState Error", ex);
            }
        }
        #endregion

        #region Helper Methods
        private void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            AppLogger.Info("Plugin::CurrentDomain_ProcessExit Called");
            try
            {
                if (!overlayTester.TestInitiated)
                {
                    overlayTester.StoreInitalStateToFile();
                }
                if (overlayTester.GETAPITestStatus(InterfacesNames.INTERFACE_IHOST, APINames.REQUEST_CLOSE) == APITestStatus.IN_PROGRESS)
                {
                    overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IHOST, APINames.REQUEST_CLOSE, APITestStatus.PASSED);
                    overlayTester.OnShutDownCalled(new EventArgs());  //Call back to store logs collection. 
                    overlayTester.StoreTestStatusToFile(); //Stores Test State To file.
                    AppLogger.Info("Plugin::RequestClose- passed");
                }
            }
            catch (Exception ex)
            {
                AppLogger.Error("Plugin::CurrentDomain_ProcessExit- Error", ex);
            }
        }


        private void pluginInitialRegistrations()
        {
            AppLogger.Info("Plugin::pluginInitialRegistrations Called");
            hostManager = new PluginHostManager();
            hostManager.ThePlugIn = this;
            hostManager.TheHost = this.host;
        }

        private void SetGlobalResources()
        {
            AppLogger.Info("Plugin::SetGlobalResources Called");
            // Set the static values that would be instantiated in App.xaml
            // Create ViewModelLocator
            //App.Current.Resources.Add("Locator", new ViewModelLocator());
            // Declare global assets
            AddResourceDictionaries
                (
                @"Resources/Helpers/Converters.xaml",
                @"Resources/Styles/Styles.xaml",
                @"Resources/Styles/Colors.xaml",
                @"Resources/Styles/Images.xaml",
                @"Resources/Styles/PluginStyles.xaml",
                @"Resources/Styles/HoverImageButtonTheme.xaml",
                @"Resources/Styles/GlobalScrollBarStyle.xaml"
                );
        }

        private void AddResourceDictionaries(params string[] uris)
        {
            foreach (string uri in uris)
            {
                ResourceDictionary resourceDict = new ResourceDictionary();
                resourceDict.Source = new Uri(uri, UriKind.Relative);
                App.Current.Resources.MergedDictionaries.Add(resourceDict);
            }
        }

        /// <summary>
        ///  Plugin params, such as Name, Description, Key and ID reading from an XML file 
        /// </summary>
        public void LoadPluginParamsFromXML()
        {
            try
            {
                AppLogger.Info("Plugin::LoadPluginParamsFromXML Called");
                //get the full location of the assembly with DaoTests in it
                string fullPath = System.Reflection.Assembly.GetAssembly(typeof(Plugin)).Location;
                AppLogger.Info("fullPath" + fullPath);
                //get the folder that's in
                string theDirectory = Path.GetDirectoryName(fullPath);
                AppLogger.Info("Directory" + theDirectory);
                AppLogger.Info("_______ ____Xml Reading__ ______");
                string PluginParamsFileUrl = Path.Combine(theDirectory, "OverlayPluginParams.xml");
                AppLogger.Info("The path for PluginParamsFileUrl is " + PluginParamsFileUrl);

                if (File.Exists(PluginParamsFileUrl))
                {
                    XDocument toolPreferenceXml = XDocument.Load(PluginParamsFileUrl);
                    toolPreferenceMapping = toolPreferenceXml.Descendants(
                        PluginConstants.PluginXmlTagIdentifier).ToDictionary(
                            x => x.Attribute(PluginConstants.PluginNameAttribute).Value,
                            x => x.Attribute(PluginConstants.PluginValueAttribute).Value);
                }
                else
                {
                    AppLogger.Info("The OverlayPluginParams.xml file not exist");
                }
            }
            catch (Exception ex)
            {
                AppLogger.Error("LoadPluginParamsFromXML", ex);
            }
        }

        #endregion

        #region IOCCPluginOverlay Implementations

        public void OnVideoPlayPause(string dataSourceId, string number, bool live, bool playing, DateTime utcTime)
        {
            pluginUIControl.Dispatcher.BeginInvoke(new Action(() =>
            {
                AppLogger.Info("IPlugin::OnVideoPlayPause Called. datasource=" + dataSourceId + ", number=" + number + ", playing=" + playing + " ,Time=" + utcTime);
                videoAPI.OnVideoPlayPause(dataSourceId, number, live, playing, utcTime);

            }));
        }
        public void OnVideoTimer(DateTime streamTime)
        {
            pluginUIControl.Dispatcher.BeginInvoke(new Action(() =>
            {
                AppLogger.Info("IPlugin::OnVideoTimer Called");
                videoAPI.OnVideoTimer(streamTime);
            }));
        }

        public void OnVideoRemoved()
        {
            pluginUIControl.Dispatcher.BeginInvoke(new Action(() =>
            {
                AppLogger.Info("IPlugin::OnVideoRemoved Called");
                videoAPI.OnVideoRemoved();
            }));
        }

        #endregion

        #region IOCCPlugin1 Implementations

        public void OnThumbnailPreferenceNotification(bool show)
        {
            //throw new NotImplementedException();
        }

        public void OnCameraOnScreeen(string cameraId, bool onScreen)
        {
            //throw new NotImplementedException();
        }

        public void ReservedSetDataSource(string dataSourceID, string number)
        {
            try
            {
                List<InputParameter> inputParams = new List<InputParameter>();
                inputParams.Add(new InputParameter() { ParameterName = "dataSourceID", ParameterType = ParameterTypeEnum.STRING, Value = dataSourceID });
                inputParams.Add(new InputParameter() { ParameterName = "number", ParameterType = ParameterTypeEnum.STRING, Value = number });

                APITestStatus testStatus = overlayTester.TestAPI(InterfacesNames.INTERFACE_IOCCPLUGIN_RESERVED, APINames.RESERVED_SET_DATASOURCE, dataSourceID, number);
                overlayTester.StoreTestStatus(InterfacesNames.INTERFACE_IOCCPLUGIN_RESERVED, APINames.RESERVED_SET_DATASOURCE, testStatus, inputParams);
            }
            catch (Exception ex)
            {
                AppLogger.Error("ReservedSetDataSource", ex);
            }
        }


        #endregion
    }
}

