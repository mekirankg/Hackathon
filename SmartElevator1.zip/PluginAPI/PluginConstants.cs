﻿/**********************************************************************************
* File Name   :   PluginConstants.cs
* Description :   This class holds plug-in specific constants
*
* Copyright (c) 2015 Pelco Products, Inc.
* --------------------------------------------------------------------------------
* Date             Author              Comment
* --------------------------------------------------------------------------------
* 17-May-2016      QuEST Team          Initial version created
**********************************************************************************/

namespace SmartElevators.PluginAPI
{
    public class PluginConstants
    {
        public const string PLUGIN_ASSEMBLY_VERSION = "1.0.0";
        public const string PLUGIN_VERSION = "Version";
        public const string PLUGIN_ID = "Id";
        public const string PLUGIN_NAME = "Name";
        public const string PLUGIN_KEY = "Key";
        public const string PLUGIN_DESCRIPTION = "Description";
        public const string PluginNameAttribute = "Name";
        public const string PluginValueAttribute = "Value";
        public const string PluginXmlTagIdentifier = "Param";

        public const string DATA_SOURCE_ID = "dataSourceId";
        public const string NUMBER = "number";
        public const string LIVE = "live";
        public const string PLAYING = "playing";
        public const string UTC_TIME = "utcTime";
    }
}
