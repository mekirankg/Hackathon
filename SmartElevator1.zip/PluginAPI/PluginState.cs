﻿/**********************************************************************************
* File Name   :   PluginState.cs
* Description :   This model class represents the state of the plug-in.
*
* Copyright (c) 2015 Pelco Products, Inc.
* --------------------------------------------------------------------------------
* Date             Author              Comment
* --------------------------------------------------------------------------------
* 23-Nov-2015      QuEST Team          Initial version created
**********************************************************************************/


using System;

namespace SmartElevators.PluginAPI
{
    public class PluginState
    {
        #region public properties

        //OnVideoPlayPause, OnVideoTimer, OnVideoRemoved variables
      

        //RequestAnnotate Variables
      
        #endregion

        #region Constructor

        public PluginState()
        {
        }

        #endregion
    }

}
