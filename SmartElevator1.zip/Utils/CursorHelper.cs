﻿using System;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;

namespace SmartElevators.Utils
{
    class SafeIconHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool DestroyIcon(
            [In] IntPtr hIcon);

        private SafeIconHandle()
            : base(true)
        {
        }

        public SafeIconHandle(IntPtr hIcon)
            : base(true)
        {
            this.SetHandle(hIcon);
        }

        protected override bool ReleaseHandle()
        {
            return DestroyIcon(this.handle);
        }
    }

    class CursorHelper
    {
        private struct IconInfo
        {
            public bool fIcon;
            public int xHotspot;
            public int yHotspot;
            public IntPtr hbmMask;
            public IntPtr hbmColor;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr CreateIconIndirect(ref IconInfo icon);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetIconInfo(IntPtr hIcon, ref IconInfo pIconInfo);

        /// <summary>
        /// Create a cursor based on the given UIElement.
        /// </summary>
        /// <param name="element"></param>
        /// <param name="xHotSpot"></param>
        /// <param name="yHotSpot"></param>
        /// <param name="addBackground">Optional if cursor should have background color added</param>
        /// <param name="backgroundBrush">Optional if addBackbround is true, specific Brush may be provided</param>
        /// <returns></returns>
        public static Cursor CreateCursor(UIElement element, int xHotSpot, int yHotSpot, bool addBackground = false, Brush backgroundBrush = null)
        {
            //keep our cursor sanely sized
            double _maxCursorHeight = 80; //UXG say 40 but it seems tiny
            double _minCursorHeight = 24;
            double cursorWidth = _minCursorHeight; //not a typo, just want a nonzero default.
            double cursorHeight = _minCursorHeight;

            if ((element.RenderSize.Height != 0) && (element.RenderSize.Width != 0))
            {
                cursorHeight = Math.Max(element.RenderSize.Height, _minCursorHeight);
                cursorHeight = Math.Min(cursorHeight, _maxCursorHeight);
                double scale = cursorHeight / element.RenderSize.Height;
                cursorWidth = element.RenderSize.Width * scale;

                //TODO: do we really want to pass in offset coords?
                xHotSpot = (int)(scale * (double)xHotSpot);
                yHotSpot = (int)(scale * (double)yHotSpot);
            }

            Cursor cur = null;
            try
            {
                RenderTargetBitmap rtb = new RenderTargetBitmap((int)cursorWidth, (int)cursorHeight, 96, 96, PixelFormats.Pbgra32);
                var brush = new VisualBrush(element);
                var visual = new DrawingVisual();

                using (DrawingContext dc = visual.RenderOpen())
                {
                    var rect = new Rect(0, 0, cursorWidth, cursorHeight);

                    if (addBackground)
                    {
                        if (backgroundBrush == null)
                        {
                            backgroundBrush = (SolidColorBrush)new BrushConverter().ConvertFromString("#55007DC5");
                        }
                        dc.DrawRectangle(backgroundBrush, null, rect);
                    }
                    dc.DrawRectangle(brush, null, rect);
                }
                rtb.Render(visual);

                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(rtb));

                using (MemoryStream ms = new MemoryStream())
                {
                    encoder.Save(ms);

                    using (System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(ms))
                    {
                        ms.Close();
                        cur = InternalCreateCursor(bmp, xHotSpot, yHotSpot);
                    }
                }
            }
            catch (Exception e)
            {
                AppLogger.Info(e.Message);
            }

            return cur;
        }

        private static Cursor InternalCreateCursor(System.Drawing.Bitmap bmp, int xHotSpot, int yHotSpot)
        {
            try
            {
                IconInfo tmp = new IconInfo();
                GetIconInfo(bmp.GetHicon(), ref tmp);
                tmp.xHotspot = xHotSpot;
                tmp.yHotspot = yHotSpot;
                tmp.fIcon = false;

                IntPtr ptr = CreateIconIndirect(ref tmp);
                if (ptr != null && ptr != IntPtr.Zero)
                {
                    SafeIconHandle handle = new SafeIconHandle(ptr);
                    if (!handle.IsInvalid)
                    {
                        Cursor cur = CursorInteropHelper.Create(handle);
                        if (cur == null)
                        {
                            AppLogger.Info("null Cursor");
                        }
                        return cur;
                    }
                }
            }
            catch (Exception e)
            {
                AppLogger.Info(e.Message);
            }

            return null;
        }
    }
}
