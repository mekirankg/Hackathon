﻿/**********************************************************************************
* File Name   :   Constants.cs
* Description :   This class holds all constants used in the application scope. 
*
* Copyright (c) 2015 Pelco Products, Inc.
* ---------------------------------------------
* 
* -----------------------------------
* Date             Author              Comment
* --------------------------------------------------------------------------------
* 23-Nov-2015      QuEST Team          Initial version created
**********************************************************************************/

namespace SmartElevators.Utils
{
    /// <summary>
    /// Class holding all constants used in application scope.
    /// </summary>
    public class Constants
    {


    }

   
}









