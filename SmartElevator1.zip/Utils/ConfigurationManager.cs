﻿using SmartElevators.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SmartElevators.Utils
{
   public class ConfigurationManager
    {
        
            #region Public Methods

            /// <summary>
            /// Gets the configuration details from the XML file.
            /// </summary>
            public static ConfigurationData GetDBConfigurationDetails()
            {
                XmlSerializer deserializer = new XmlSerializer(typeof(ConfigurationData));
                string currentPath = Path.GetDirectoryName(new Uri(Assembly.GetExecutingAssembly().CodeBase).LocalPath);
                string fileName = currentPath + "\\Configuration\\Configuration.config";
                TextReader reader = new StreamReader(fileName);
                object obj = deserializer.Deserialize(reader);
                 ConfigurationData XmlData = (ConfigurationData)obj;
                
                reader.Close();

                return XmlData;
            }            

            #endregion
       
    }
}
