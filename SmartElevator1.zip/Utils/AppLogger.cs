﻿/**********************************************************************************
* File Name   :   Logger.cs
* Description :   This class takes care of all logging functionalities 
*                 of entire application
*
* Copyright (c) 2015 Pelco Products, Inc.
* --------------------------------------------------------------------------------
* Date             Author              Comment
* --------------------------------------------------------------------------------
* 23-Nov-2015      QuEST Team          Initial version created
**********************************************************************************/

using NLog;
using NLog.Config;
using NLog.Targets;
using System;

namespace SmartElevators.Utils
{
    /// <summary>
    /// Wrapper class for NLog logging
    /// </summary>
    public static class AppLogger
    {
        private static NLog.Logger logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Static constructor of AppLogger
        /// </summary>
        static AppLogger()
        {
            string logFileName = String.Format("{0}_{1}_{2}.log", "SmartElevator",
                DateTime.Now.ToString("MM-dd-yyyy"), Guid.NewGuid().ToString("D"));
            string logFilePath = "${specialfolder:folder=CommonApplicationData}/Pelco/Logs/" + logFileName;

            // Step 1. Create configuration object 
            var config = new LoggingConfiguration();

            // Step 2. Create target and add them to the configuration 
            var fileTarget = new FileTarget();
            config.AddTarget("file", fileTarget);

            // Step 3. Set target properties 
            fileTarget.FileName = logFilePath;
            fileTarget.Layout = "${date} - ${message} ${exception:format=message,stacktrace:separator=*}";

            // Step 4. Define rules
            var logRule = new LoggingRule("*", LogLevel.Trace, fileTarget);
            config.LoggingRules.Add(logRule);

            // Step 5. Activate the configuration
            LogManager.Configuration = config;
        }

        /// <summary>
        /// Logs trace messages
        /// </summary>
        /// <param name="message">Message to be logged</param>
        /// <param name="exception">Exception [Optional]</param>
        public static void Trace(
            string message,
            Exception exception = null)
        {
            Log(LogLevel.Trace, message, exception);
        }

        /// <summary>
        /// Logs debug messages
        /// </summary>
        /// <param name="message">Message to be logged</param>
        /// <param name="exception">Exception [Optional]</param>
        public static void Debug(
            string message,
            Exception exception = null)
        {
            Log(LogLevel.Debug, message, exception);
        }

        /// <summary>
        /// Logs information messages
        /// </summary>
        /// <param name="message">Message to be logged</param>
        /// <param name="exception">Exception [Optional]</param>
        public static void Info(
            string message,
            Exception exception = null)
        {
            Log(LogLevel.Info, message, exception);
        }

        /// <summary>
        /// Logs warning messages
        /// </summary>
        /// <param name="message">Message to be logged</param>
        /// <param name="exception">Exception [Optional]</param>
        public static void Warn(
            string message,
            Exception exception = null)
        {
            Log(LogLevel.Warn, message, exception);
        }

        /// <summary>
        /// Logs error messages
        /// </summary>
        /// <param name="message">Message to be logged</param>
        /// <param name="exception">Exception [Optional]</param>
        public static void Error(
            string message,
            Exception exception = null)
        {
            Log(LogLevel.Error, message, exception);
#if DEBUG
            System.Diagnostics.Debugger.Launch();
#endif
        }

        /// <summary>
        /// Logs fatal messages
        /// </summary>
        /// <param name="message">Message to be logged</param>
        /// <param name="exception">Exception [Optional]</param>
        public static void Fatal(
            string message,
            Exception exception = null)
        {
            Log(LogLevel.Fatal, message, exception);
        }

        /// <summary>
        /// Logs exception
        /// </summary>
        /// <param name="exception">Exception object</param>
        public static void ErrorException(Exception exception)
        {
            Log(LogLevel.Error, exception.Message, exception);
        }

        /// <summary>
        /// Logs the message
        /// </summary>
        /// <param name="level">Log level</param>
        /// <param name="message">Log message</param>
        /// <param name="exception">Exception [Optional]</param>
        private static void Log(
            LogLevel level,
            string message,
            Exception exception = null)
        {
            logger.Log(level, message, exception);
        }
    }
}
