﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartElevators.Utils
{
    public static class Helper
    {
        /// <summary>
        /// Gets the base 64 encoded string from given string
        /// </summary>
        /// <param name="source">Input string</param>
        /// <returns>Base 64 encoded string</returns>
        public static string Encode(string source)
        {
            var bytes = Encoding.UTF8.GetBytes(source);
            return Convert.ToBase64String(bytes);
        }
    }
}
