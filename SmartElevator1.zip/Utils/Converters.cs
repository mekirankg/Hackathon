﻿/**********************************************************************************
* File Name   :   Converters.cs
* Description :   This code file holds declarations of all value converters 
*                 used in the application. All converters declared here, 
*                 must be instantiated at Resources/Helpers/Converters.xaml
*
* Copyright (c) 2015 Pelco Products, Inc.
* --------------------------------------------------------------------------------
* Date             Author              Comment
* --------------------------------------------------------------------------------
* 23-Nov-2015      QuEST Team          Initial version created
**********************************************************************************/

using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using SmartElevators.ViewModel;

using System.Windows;

namespace SmartElevators.Utils
{
    public class IsNullConverter : IValueConverter
    {
        private bool inverted = false;

        public bool Inverted
        {
            get { return inverted; }
            set { inverted = value; }
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Inverted ? value != null : value == null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new InvalidOperationException("IsNullConverter can only be used OneWay.");
        }
    }

    /// <summary>
    /// Convert the forground according to test status
    /// </summary>
    public class ForgroundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string str = value as string;
            if (string.IsNullOrEmpty(str))
            {
                return new SolidColorBrush(Colors.White);
            }

            if (str.Contains("PASSED"))
                return new SolidColorBrush(Color.FromArgb(255, 151, 203, 89));

            else if (str.Contains("FAILED"))
                return new SolidColorBrush(Color.FromArgb(255, 204, 0, 0));

            else if (str.Contains("IN_PROGRESS"))
                return new SolidColorBrush(Color.FromArgb(255, 0, 125, 197));

            else if (str.Contains("PENDING"))
                return new SolidColorBrush(Color.FromArgb(255, 247, 132, 2));

            else
                return new SolidColorBrush(Colors.White);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Convert the capital words to title case
    /// </summary>
    public class ConstantConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var status = value;
            string str = status.ToString();
            str = str.Replace("_", " ");
            str = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
            return str;

        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Convert the uValue of joystick to a displayable value
    /// </summary>
    public class UValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double uValue = (double)value;

            if (uValue == 0)
            {
                uValue = 0.50;
            }
            return uValue;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Returns placeholder text based on PlaceHolder property value
    /// </summary>
    public class PlaceHolderConverter : IMultiValueConverter
    {
        public object Convert(object[] value, Type targetType, object parameter, CultureInfo culture)
        {
            var text = value[0];
            bool placeholder = (bool)value[1];

            if (text == null)
            {
                if (placeholder)
                {
                    text = "Drop Camera/Bookmark";
                }
                else
                {
                    text = "Drop Camera/Bookmark/Plug-in";
                }
            }
            return text;
        }

        public object[] ConvertBack(object value, Type[] targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Determines IsEnabled property of Button 
    /// </summary>
    public class IsEnableConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (parameter.ToString() == "DropAreaClear" | parameter.ToString() == "DragItemSetupClear")
            {
                //LaunchObjectContent dropItem = (LaunchObjectContent)value;
                bool input = (bool)value;

                if (input == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            //else if (parameter.ToString() == "DragItemSetupClear")
            //{
            //    int count = (int)value;

            //    if(dropItem.DataSourceId != null)
            //    {
            //        return true;
            //    }
            //    else
            //    {
            //        return false;
            //    }
            //}
            else
            {
                int count = (int)value;

                if (count == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Convert the content of status view toggle button
    /// </summary>
    public class StateButtonContentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string content = "Unknown";

           
            return content;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

   

   

   
}
