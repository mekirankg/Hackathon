﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using Emgu.CV;
using Emgu.Util;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using FaceDetection;
using Emgu.CV.UI;
using Emgu.CV.Cuda;

namespace FaceCouter
{
    public partial class Form1 : Form
    {
        private VideoCapture _capture = null;
        private bool _captureInProgress;
        private Mat _frame;
        private Mat _grayFrame;
        private Mat _smallGrayFrame;
        private Mat _smoothedGrayFrame;
        private Mat _cannyFrame;

        public Form1()
        {
           
            InitializeComponent();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                _capture = new VideoCapture("rtsp://10.1.26.117/stream1");
                    //@"E:\Work\PELCO\IdeaThon\FaceCouter\FaceCouter\bin\Debug\SampleVideo.mp4");
                _capture.ImageGrabbed += ProcessFrame;
                _capture.Start();
            }
            catch (NullReferenceException excpt)
            {
                MessageBox.Show(excpt.Message);
            }
            _frame = new Mat();
            _grayFrame = new Mat();
            _smallGrayFrame = new Mat();
            _smoothedGrayFrame = new Mat();
            _cannyFrame = new Mat();
        }

        private void ProcessFrame(object sender, EventArgs arg)
        {
            if (_capture != null && _capture.Ptr != IntPtr.Zero)
            {
                _capture.Retrieve(_frame, 0);

                //CvInvoke.CvtColor(_frame, _grayFrame, ColorConversion.Bgr2Gray);

                //CvInvoke.PyrDown(_grayFrame, _smallGrayFrame);

                //CvInvoke.PyrUp(_smallGrayFrame, _smoothedGrayFrame);

                //CvInvoke.Canny(_smoothedGrayFrame, _cannyFrame, 100, 60);

                ////imageBox1.Image = _capture. QueryFrame();
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                pictureBox1.Image = _frame.Bitmap;
                //grayscaleImageBox.Image = _grayFrame;
                //smoothedGrayscaleImageBox.Image = _smoothedGrayFrame;
                //cannyImageBox.Image = _cannyFrame;
                #region Sample code
                //long detectionTime;
                //List<Rectangle> faces = new List<Rectangle>();
                //List<Rectangle> eyes = new List<Rectangle>();

                //DetectFace.Detect(
                //  _frame, "haarcascade_frontalface_default.xml", "haarcascade_eye.xml",
                //  faces, eyes,
                //  out detectionTime);

                //foreach (Rectangle face in faces)
                //    CvInvoke.Rectangle(_frame, face, new Bgr(Color.Red).MCvScalar, 2);
                //{ 
                ////foreach (Rectangle eye in eyes)
                ////    CvInvoke.Rectangle(_frame, eye, new Bgr(Color.Blue).MCvScalar, 2);


                //    //display the image 
                //    using (InputArray iaImage = _frame.GetInputArray())
                //        ImageViewer.Show(_frame, String.Format(
                //           "Completed face and eye detection using {0} in {1} milliseconds",
                //           (iaImage.Kind == InputArray.Type.CudaGpuMat && CudaInvoke.HasCuda) ? "CUDA" :
                //           (iaImage.IsUMat && CvInvoke.UseOpenCL) ? "OpenCL"
                //           : "CPU",
                //           detectionTime));
                //}
                #endregion
                #region internet
                var _cascadeClassifier = new CascadeClassifier("haarcascade_frontalface_alt_tree.xml");
                var _cascadeClassifier1 = new CascadeClassifier("haarcascade_frontalface_default.xml");
                var _cascadeClassifier2 = new CascadeClassifier("HS.xml");
                
                using (var imageFrame = _frame.ToImage<Bgr, Byte>())//_capture.QueryFrame().ToImage<Bgr, Byte>())
                {
                    if (imageFrame != null)
                    {
                        var grayframe = imageFrame.Convert<Gray, byte>();
                        var faces = _cascadeClassifier.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                        var faces1 = _cascadeClassifier1.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                        var faces2 = _cascadeClassifier1.DetectMultiScale(grayframe, 1.1, 10, Size.Empty); //the actual face detection happens here
                        var actualFace = GetValidFace(faces, faces1, faces2);
                        label2.Text = "face : " + faces.Length;
                        label3.Text = "face 1: " + faces1.Length;
                        foreach (var face in faces1)
                        {
                            imageFrame.Draw(face, new Bgr(Color.BurlyWood), 3); //the detected face(s) is highlighted here using a box that is drawn around it/them
                            detected.SizeMode = PictureBoxSizeMode.AutoSize;
                            detected.Image = imageFrame.Bitmap;
                            txtCount.Text = faces1.Length.ToString();
                            
                            //break;
                            //MessageBox.Show("Found it");
                           // using (InputArray iaImage = _frame.GetInputArray())
                               // ImageViewer.Show(_frame);
                        }
                    }
                    //imgCamUser.Image = imageFrame;
                    
                }
                #endregion

            }
        }

        private object GetValidFace(Rectangle[] faces, Rectangle[] faces1, Rectangle[] faces2)
        {
            
            //        4           5                                  7
            //return (faces.Length > faces1.Length ? (faces.Length > faces2.Length ? faces : faces2) : (faces1.Length);
            return null;
        }
    }
}
